import sqlite3
import os
import shutil
from datetime import datetime
from config import (
    DEFAULT_SECRET_PASSWORD,
    REQUIRED_REFERRALS,
    DEFAULT_BANNER_URL,
    GROUP_1_NAME,
    GROUP_1_URL,
    GROUP_2_NAME,
    GROUP_2_URL,
    ADMIN_IDS,
)

DB_PATH = os.path.join(os.path.dirname(__file__), "bot_database.db")
DEFAULT_ADMIN_CODE = "VIP_ADMIN_SECRET_2026"

def get_connection():
    conn = sqlite3.connect(DB_PATH, timeout=10.0)
    conn.row_factory = sqlite3.Row
    # High-Reliability & Anti-Corruption SQLite Pragmas (WAL Mode)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    conn.execute("PRAGMA busy_timeout=5000;")
    return conn

def create_backup() -> str:
    """
    Creates a safe, consistent live snapshot of the SQLite database
    using SQLite's native backup API. Prevents database corruption or data loss
    even if the bot process or host abruptly shuts down.
    """
    backup_dir = os.path.join(os.path.dirname(__file__), "backups")
    os.makedirs(backup_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = os.path.join(backup_dir, f"backup_{timestamp}.db")

    try:
        src_conn = sqlite3.connect(DB_PATH, timeout=10.0)
        dst_conn = sqlite3.connect(backup_file)
        with dst_conn:
            src_conn.backup(dst_conn)
        dst_conn.close()
        src_conn.close()

        # Mirror copy to root directory backup file
        mirror_file = os.path.join(os.path.dirname(__file__), "bot_database_backup.db")
        shutil.copy2(backup_file, mirror_file)

        # Retain last 10 backups to prevent infinite disk usage
        backups = sorted(
            [os.path.join(backup_dir, f) for f in os.listdir(backup_dir) if f.startswith("backup_") and f.endswith(".db")],
            key=os.path.getmtime
        )
        while len(backups) > 10:
            oldest = backups.pop(0)
            try:
                os.remove(oldest)
            except Exception:
                pass

        return backup_file
    except Exception as e:
        print(f"Backup warning: {e}")
        return ""

def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    # Users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            joined_groups INTEGER DEFAULT 0,
            referred_by INTEGER,
            has_claimed_reward INTEGER DEFAULT 0,
            spent_referrals INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Ensure spent_referrals column exists in case table was created earlier
    try:
        cursor.execute("PRAGMA table_info(users)")
        columns = [col[1] for col in cursor.fetchall()]
        if "spent_referrals" not in columns:
            cursor.execute("ALTER TABLE users ADD COLUMN spent_referrals INTEGER DEFAULT 0")
    except Exception:
        pass

    # Referrals table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS referrals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            referrer_id INTEGER NOT NULL,
            referred_user_id INTEGER NOT NULL UNIQUE,
            is_verified INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(referrer_id) REFERENCES users(user_id),
            FOREIGN KEY(referred_user_id) REFERENCES users(user_id)
        )
    """)

    # Settings table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
    """)

    # Products / Rewards table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            secret_password TEXT NOT NULL,
            required_referrals INTEGER NOT NULL DEFAULT 2,
            is_active INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # User product claims table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS user_claims (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            claimed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Key Stock table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS key_stock (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key_value TEXT NOT NULL UNIQUE,
            is_used INTEGER DEFAULT 0,
            used_by INTEGER,
            used_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Admins table for secret code authentication
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS admins (
            user_id INTEGER PRIMARY KEY,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Pre-authorize owner ID 8884471241 and any IDs in config
    for aid in ADMIN_IDS:
        if aid.isdigit():
            cursor.execute("INSERT OR IGNORE INTO admins (user_id) VALUES (?)", (int(aid),))

    # Seed default settings
    default_settings = {
        "secret_password": DEFAULT_SECRET_PASSWORD,
        "required_referrals": str(REQUIRED_REFERRALS),
        "banner_url": DEFAULT_BANNER_URL,
        "admin_secret_code": DEFAULT_ADMIN_CODE,
        "group1_name": GROUP_1_NAME,
        "group1_url": GROUP_1_URL,
        "group2_name": GROUP_2_NAME,
        "group2_url": GROUP_2_URL,
    }

    for k, v in default_settings.items():
        cursor.execute("SELECT value FROM settings WHERE key = ?", (k,))
        if not cursor.fetchone():
            cursor.execute("INSERT INTO settings (key, value) VALUES (?, ?)", (k, v))

    # Seed initial products if none exist
    cursor.execute("SELECT COUNT(*) FROM products")
    if cursor.fetchone()[0] == 0:
        cursor.execute("""
            INSERT INTO products (name, description, secret_password, required_referrals)
            VALUES (?, ?, ?, ?)
        """, ("🔥 VIP Panel Access Key", "Full VIP Access to Free Panel Server", DEFAULT_SECRET_PASSWORD, REQUIRED_REFERRALS))
        cursor.execute("""
            INSERT INTO products (name, description, secret_password, required_referrals)
            VALUES (?, ?, ?, ?)
        """, ("💎 Premium Mod Pro Key", "Exclusive High-Speed VIP Mod Feature", "PRO_MOD_KEY_2026", 3))

    conn.commit()
    conn.close()

    # Safety: Create automated live snapshot backup on startup
    try:
        create_backup()
    except Exception:
        pass

# Settings helpers
def get_setting(key: str, default: str = "") -> str:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT value FROM settings WHERE key = ?", (key,))
    row = cursor.fetchone()
    conn.close()
    return row["value"] if row else default

def set_setting(key: str, value: str):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO settings (key, value) VALUES (?, ?)
        ON CONFLICT(key) DO UPDATE SET value = excluded.value
    """, (key, str(value)))
    conn.commit()
    conn.close()

# Group & Channel Management
def extract_chat_id(val: str) -> str:
    val = (val or "").strip()
    if not val:
        return ""
    if val.startswith("@") or val.startswith("-"):
        return val
    if "t.me/" in val:
        part = val.split("t.me/")[-1].split("/")[0].split("?")[0].strip()
        if not part.startswith("+") and not part.startswith("joinchat") and part:
            return f"@{part}"
    return val

def get_groups():
    g1_url = get_setting("group1_url", GROUP_1_URL)
    g2_url = get_setting("group2_url", GROUP_2_URL)
    g1_id = get_setting("group1_id", "") or extract_chat_id(g1_url)
    g2_id = get_setting("group2_id", "") or extract_chat_id(g2_url)
    return {
        "g1_name": get_setting("group1_name", GROUP_1_NAME),
        "g1_url": g1_url,
        "g1_id": g1_id,
        "g2_name": get_setting("group2_name", GROUP_2_NAME),
        "g2_url": g2_url,
        "g2_id": g2_id,
    }

def set_group1(name: str, url: str, chat_id: str = ""):
    set_setting("group1_name", name)
    set_setting("group1_url", url)
    final_id = chat_id.strip() if chat_id.strip() else extract_chat_id(url)
    if final_id:
        set_setting("group1_id", final_id)

def set_group2(name: str, url: str, chat_id: str = ""):
    set_setting("group2_name", name)
    set_setting("group2_url", url)
    final_id = chat_id.strip() if chat_id.strip() else extract_chat_id(url)
    if final_id:
        set_setting("group2_id", final_id)

# Admin Authorization & Secret Code
def is_admin(user_id: int) -> bool:
    if str(user_id) == "8884471241" or str(user_id) in ADMIN_IDS:
        return True
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM admins WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    return bool(row)

def add_admin(user_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT OR IGNORE INTO admins (user_id) VALUES (?)", (user_id,))
    conn.commit()
    conn.close()

def get_admin_secret_code() -> str:
    return get_setting("admin_secret_code", DEFAULT_ADMIN_CODE)

def set_admin_secret_code(new_code: str):
    set_setting("admin_secret_code", new_code)

def get_banner_url() -> str:
    return get_setting("banner_url", DEFAULT_BANNER_URL)

def set_banner_url(url: str):
    set_setting("banner_url", url)

def get_required_referrals() -> int:
    val = get_setting("required_referrals", str(REQUIRED_REFERRALS))
    try:
        return int(val)
    except ValueError:
        return REQUIRED_REFERRALS

def set_required_referrals(num: int):
    set_setting("required_referrals", str(num))

def get_secret_password() -> str:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT secret_password FROM products WHERE is_active = 1 ORDER BY id ASC LIMIT 1")
    row = cursor.fetchone()
    conn.close()
    if row and row["secret_password"]:
        return row["secret_password"]
    return get_setting("secret_password", DEFAULT_SECRET_PASSWORD)

def set_secret_password(new_pwd: str):
    set_setting("secret_password", new_pwd)
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE products SET secret_password = ? WHERE id = (SELECT id FROM products ORDER BY id ASC LIMIT 1)", (new_pwd,))
    if cursor.rowcount == 0:
        cursor.execute("""
            INSERT INTO products (name, description, secret_password, required_referrals, is_active)
            VALUES (?, ?, ?, ?, 1)
        """, ("🔥 VIP Access Key", "Full VIP Access Key", new_pwd, get_required_referrals()))
    conn.commit()
    conn.close()

# --- Products CRUD ---
def get_all_products(only_active: bool = True):
    conn = get_connection()
    cursor = conn.cursor()
    if only_active:
        cursor.execute("SELECT * FROM products WHERE is_active = 1 ORDER BY required_referrals ASC, id ASC")
    else:
        cursor.execute("SELECT * FROM products ORDER BY id ASC")
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_product(product_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products WHERE id = ?", (product_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def add_product(name: str, secret_password: str, required_referrals: int = 2, description: str = "") -> int:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO products (name, description, secret_password, required_referrals, is_active)
        VALUES (?, ?, ?, ?, 1)
    """, (name, description, secret_password, required_referrals))
    prod_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return prod_id

def update_product_password(product_id: int, new_password: str) -> bool:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE products SET secret_password = ? WHERE id = ?", (new_password, product_id))
    affected = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return affected

def update_product_referrals(product_id: int, required_referrals: int) -> bool:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE products SET required_referrals = ? WHERE id = ?", (required_referrals, product_id))
    affected = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return affected

def delete_product(product_id: int) -> bool:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM products WHERE id = ?", (product_id,))
    affected = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return affected

def record_user_claim(user_id: int, product_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO user_claims (user_id, product_id) VALUES (?, ?)
    """, (user_id, product_id))
    cursor.execute("UPDATE users SET has_claimed_reward = 1 WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()

# --- Key Stock CRUD ---
def add_stock_keys(keys_list: list) -> int:
    conn = get_connection()
    cursor = conn.cursor()
    added = 0
    for k in keys_list:
        k = k.strip()
        if k:
            try:
                cursor.execute("INSERT OR IGNORE INTO key_stock (key_value) VALUES (?)", (k,))
                if cursor.rowcount > 0:
                    added += 1
            except Exception:
                pass
    conn.commit()
    conn.close()
    return added

def get_stock_stats() -> dict:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM key_stock WHERE is_used = 0")
    available = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM key_stock WHERE is_used = 1")
    used = cursor.fetchone()[0]
    total = available + used
    conn.close()
    return {"available": available, "used": used, "total": total}

def get_recent_available_keys(limit: int = 5) -> list:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT key_value FROM key_stock WHERE is_used = 0 ORDER BY id ASC LIMIT ?", (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [r["key_value"] for r in rows]

def delete_stock_keys(count: int = 1) -> int:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        DELETE FROM key_stock 
        WHERE id IN (
            SELECT id FROM key_stock WHERE is_used = 0 ORDER BY id DESC LIMIT ?
        )
    """, (count,))
    deleted = cursor.rowcount
    conn.commit()
    conn.close()
    return deleted

def clear_all_unused_stock() -> int:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM key_stock WHERE is_used = 0")
    deleted = cursor.rowcount
    conn.commit()
    conn.close()
    return deleted

def claim_new_stock_key(user_id: int) -> str:
    """Pop the next unused key from key_stock for this user, or fallback to default secret password."""
    conn = get_connection()
    cursor = conn.cursor()

    # Pop next unused key
    cursor.execute("SELECT id, key_value FROM key_stock WHERE is_used = 0 ORDER BY id ASC LIMIT 1")
    available_row = cursor.fetchone()
    if available_row:
        stock_id = available_row["id"]
        key_val = available_row["key_value"]
        cursor.execute("UPDATE key_stock SET is_used = 1, used_by = ?, used_at = CURRENT_TIMESTAMP WHERE id = ?", (user_id, stock_id))
        conn.commit()
        conn.close()
        return key_val

    conn.close()
    # Fallback to secret_password setting
    return get_secret_password()

def claim_or_get_user_key(user_id: int) -> str:
    return claim_new_stock_key(user_id)

# Users & Referrals
def get_or_create_user(user_id: int, username: str = None, first_name: str = None, referrer_id: int = None):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()

    is_new = False
    valid_referrer = None

    if row is None:
        is_new = True
        if referrer_id and referrer_id != user_id:
            valid_referrer = referrer_id

        cursor.execute("""
            INSERT INTO users (user_id, username, first_name, joined_groups, referred_by, has_claimed_reward)
            VALUES (?, ?, ?, 0, ?, 0)
        """, (user_id, username, first_name, valid_referrer))

        if valid_referrer:
            try:
                cursor.execute("""
                    INSERT OR IGNORE INTO referrals (referrer_id, referred_user_id, is_verified)
                    VALUES (?, ?, 0)
                """, (valid_referrer, user_id))
            except Exception:
                pass

        conn.commit()
        cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        row = cursor.fetchone()
    else:
        # User already exists
        if row["referred_by"] is None and not row["joined_groups"] and referrer_id and referrer_id != user_id:
            valid_referrer = referrer_id
            cursor.execute("""
                UPDATE users SET username = ?, first_name = ?, referred_by = ? WHERE user_id = ?
            """, (username, first_name, valid_referrer, user_id))
            try:
                cursor.execute("""
                    INSERT OR IGNORE INTO referrals (referrer_id, referred_user_id, is_verified)
                    VALUES (?, ?, 0)
                """, (valid_referrer, user_id))
            except Exception:
                pass
            conn.commit()
            cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
            row = cursor.fetchone()
            is_new = True
        else:
            cursor.execute("""
                UPDATE users SET username = ?, first_name = ? WHERE user_id = ?
            """, (username, first_name, user_id))
            conn.commit()

    user = dict(row)
    conn.close()
    return user, is_new

def mark_user_joined(user_id: int):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    user = cursor.fetchone()

    if not user:
        conn.close()
        return False, None, 0

    already_joined = bool(user["joined_groups"])
    referrer_id = user["referred_by"]
    referrer_count = 0

    if not already_joined:
        cursor.execute("UPDATE users SET joined_groups = 1 WHERE user_id = ?", (user_id,))
        if referrer_id:
            cursor.execute("""
                UPDATE referrals SET is_verified = 1 WHERE referred_user_id = ?
            """, (user_id,))
        conn.commit()

    if referrer_id:
        cursor.execute("""
            SELECT COUNT(*) FROM referrals WHERE referrer_id = ? AND is_verified = 1
        """, (referrer_id,))
        referrer_count = cursor.fetchone()[0]

    conn.close()
    return (not already_joined), referrer_id, referrer_count

def is_user_joined_db(user_id: int) -> bool:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT joined_groups FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    return bool(row and row["joined_groups"])

def get_referral_stats(user_id: int):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT 
            SUM(CASE WHEN is_verified = 1 THEN 1 ELSE 0 END) AS verified,
            SUM(CASE WHEN is_verified = 0 THEN 1 ELSE 0 END) AS pending
        FROM referrals WHERE referrer_id = ?
    """, (user_id,))
    res = cursor.fetchone()

    cursor.execute("SELECT spent_referrals FROM users WHERE user_id = ?", (user_id,))
    u_row = cursor.fetchone()
    spent = u_row["spent_referrals"] if u_row and u_row["spent_referrals"] else 0
    conn.close()

    total_verified = int(res["verified"]) if res and res["verified"] else 0
    pending = int(res["pending"]) if res and res["pending"] else 0
    available = max(0, total_verified - spent)
    return available, pending

def get_referral_full_stats(user_id: int) -> dict:
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT 
            SUM(CASE WHEN is_verified = 1 THEN 1 ELSE 0 END) AS verified,
            SUM(CASE WHEN is_verified = 0 THEN 1 ELSE 0 END) AS pending
        FROM referrals WHERE referrer_id = ?
    """, (user_id,))
    res = cursor.fetchone()

    cursor.execute("SELECT spent_referrals FROM users WHERE user_id = ?", (user_id,))
    u_row = cursor.fetchone()
    spent = u_row["spent_referrals"] if u_row and u_row["spent_referrals"] else 0
    conn.close()

    total_verified = int(res["verified"]) if res and res["verified"] else 0
    pending = int(res["pending"]) if res and res["pending"] else 0
    available = max(0, total_verified - spent)
    return {
        "available": available,
        "total_verified": total_verified,
        "pending": pending,
        "spent": spent
    }

def spend_referrals(user_id: int, count: int) -> bool:
    """Deduct referral balance by increasing spent_referrals."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE users 
        SET spent_referrals = COALESCE(spent_referrals, 0) + ? 
        WHERE user_id = ?
    """, (count, user_id))
    affected = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return affected

def revoke_user_membership(user_id: int):
    """
    Called when a user leaves a group or is banned.
    Sets joined_groups = 0 on user.
    If this user was a verified referral, un-verifies the referral (is_verified = 0),
    deducting 1 referral point from their referrer.
    Returns (referrer_id, was_verified).
    """
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT referred_by, joined_groups FROM users WHERE user_id = ?", (user_id,))
    u = cursor.fetchone()
    if not u:
        conn.close()
        return None, False

    referrer_id = u["referred_by"]
    cursor.execute("UPDATE users SET joined_groups = 0 WHERE user_id = ?", (user_id,))

    was_verified = False
    if referrer_id:
        cursor.execute("SELECT is_verified FROM referrals WHERE referred_user_id = ?", (user_id,))
        ref_row = cursor.fetchone()
        if ref_row and ref_row["is_verified"] == 1:
            was_verified = True
            cursor.execute("UPDATE referrals SET is_verified = 0 WHERE referred_user_id = ?", (user_id,))

    conn.commit()
    conn.close()
    return referrer_id, was_verified

def get_verified_referral_user_ids(referrer_id: int) -> list:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT referred_user_id FROM referrals WHERE referrer_id = ? AND is_verified = 1", (referrer_id,))
    rows = cursor.fetchall()
    conn.close()
    return [r["referred_user_id"] for r in rows]

def get_referral_list(user_id: int, limit: int = 10):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT r.is_verified, r.created_at, u.first_name, u.username
        FROM referrals r
        JOIN users u ON r.referred_user_id = u.user_id
        WHERE r.referrer_id = ?
        ORDER BY r.created_at DESC
        LIMIT ?
    """, (user_id, limit))

    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_leaderboard(limit: int = 10):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT u.user_id, u.first_name, u.username, COUNT(r.id) as ref_count
        FROM users u
        JOIN referrals r ON u.user_id = r.referrer_id
        WHERE r.is_verified = 1
        GROUP BY u.user_id
        ORDER BY ref_count DESC
        LIMIT ?
    """, (limit,))

    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_total_stats():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM users")
    total_users = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM users WHERE joined_groups = 1")
    joined_users = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM referrals WHERE is_verified = 1")
    total_completed_referrals = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM products WHERE is_active = 1")
    total_products = cursor.fetchone()[0]

    try:
        cursor.execute("SELECT COUNT(*) FROM user_claims")
        total_claimed = cursor.fetchone()[0]
    except Exception:
        total_claimed = 0

    conn.close()
    return {
        "total_users": total_users,
        "joined_users": joined_users,
        "completed_referrals": total_completed_referrals,
        "total_products": total_products,
        "total_claimed": total_claimed
    }

def get_user_details(user_id: int):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    user = cursor.fetchone()
    if not user:
        conn.close()
        return None

    # Get referrals breakdown
    cursor.execute("""
        SELECT 
            SUM(CASE WHEN is_verified = 1 THEN 1 ELSE 0 END) AS verified,
            SUM(CASE WHEN is_verified = 0 THEN 1 ELSE 0 END) AS pending
        FROM referrals WHERE referrer_id = ?
    """, (user_id,))
    res = cursor.fetchone()

    total_verified = int(res["verified"]) if res and res["verified"] else 0
    pending = int(res["pending"]) if res and res["pending"] else 0
    u_dict = dict(user)
    spent = u_dict.get("spent_referrals") or 0
    available = max(0, total_verified - spent)

    # Get claims
    cursor.execute("""
        SELECT p.name, c.claimed_at 
        FROM user_claims c 
        JOIN products p ON c.product_id = p.id 
        WHERE c.user_id = ?
        ORDER BY c.claimed_at DESC
    """, (user_id,))
    claims = [dict(c) for c in cursor.fetchall()]

    conn.close()
    return {
        "user": u_dict,
        "available_refs": available,
        "total_verified_refs": total_verified,
        "spent_refs": spent,
        "pending_refs": pending,
        "verified_refs": available,
        "claims": claims
    }

def get_recent_users(limit: int = 15):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT 
            u.user_id, 
            u.first_name, 
            u.username, 
            u.joined_groups, 
            u.spent_referrals, 
            u.created_at,
            COUNT(CASE WHEN r.is_verified = 1 THEN 1 END) AS total_verified,
            COUNT(CASE WHEN r.is_verified = 0 THEN 1 END) AS pending
        FROM users u
        LEFT JOIN referrals r ON u.user_id = r.referrer_id
        GROUP BY u.user_id
        ORDER BY u.created_at DESC 
        LIMIT ?
    """, (limit,))
    rows = cursor.fetchall()
    conn.close()
    res = []
    for r in rows:
        d = dict(r)
        spent = d.get("spent_referrals") or 0
        total_v = d.get("total_verified") or 0
        d["available"] = max(0, total_v - spent)
        d["spent"] = spent
        res.append(d)
    return res

def get_all_user_ids():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM users")
    ids = [row["user_id"] for row in cursor.fetchall()]
    conn.close()
    return ids
