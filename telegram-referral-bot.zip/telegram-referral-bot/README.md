# 💎 VIP Telegram Referral & Rewards Bot (Clean 3-Dot Menu Edition)

An ultra-clean, professional Telegram Referral & Multi-Product VIP Bot. Built with Telegram's native **3-Dot Menu**, complete stealth admin protection via secret login code, and full in-bot management (change group links, add/remove products, upload banners, broadcast news, inspect user details).

---

## 🌟 Key Features

1. **Clean & Sleek UI (Native 3-Dot Menu)**:
   - No clunky custom keyboard buttons taking up the chat window.
   - All navigation is handled natively through Telegram's bottom-left **Menu Button (/)**:
     - `/start` — 🚀 Open VIP Dashboard
     - `/claim` — 🎁 View & Claim Product Passwords
     - `/refer` — 🔗 My Referral Link & Share
     - `/status` — 📊 My Referral Progress
     - `/leaderboard` — 🏆 Top Referrers
     - `/help` — ℹ️ Rules & Support
2. **🔐 Secret Admin Login & 100% Stealth Security**:
   - Normal users **never see any admin buttons or options**.
   - Admin access can be claimed via secret passkey:
     ```
     /login VIP_ADMIN_SECRET_2026
     ```
   - Only authorized admins can open the `/admin` console.
3. **🛠 100% In-Bot Management (Zero Code Editing Needed)**:
   - **Change Group/Channel Links**:
     - `/setgroup1 <Name> | <URL>`
     - `/setgroup2 <Name> | <URL>`
   - **Manage Products & Passwords**:
     - `/addproduct <Name> | <Password> | <Referrals> | <Description>`
     - `/setprodpass <id> <new_password>`
     - `/setprodref <id> <target_referrals>`
     - `/delproduct <id>`
   - **Upload Banner Pictures**:
     - `/setpic <image_url>` or upload any photo with caption `/setpic`.
   - **Broadcast News Announcements**:
     - Send text news: `/broadcast <message>`
     - Send photo news: Upload photo with caption `/broadcast <message>`
   - **Inspect User Details**:
     - `/user <user_id>` — Shows full user profile, verified referrals, and products claimed.

---

## 🚀 Running the Bot

- **Windows One-Click**: Double-click [run.bat](file:///C:/Users/najmul/.gemini/antigravity-ide/scratch/telegram-referral-bot/run.bat).
- **Command Line**:
  ```powershell
  .venv\Scripts\python.exe bot.py
  ```
