@echo off
title Telegram Referral Bot
echo ========================================
echo    Starting Telegram Referral Bot...
echo ========================================
cd /d "%~dp0"
if exist .venv\Scripts\python.exe (
    .venv\Scripts\python.exe bot.py
) else (
    python bot.py
)
pause
