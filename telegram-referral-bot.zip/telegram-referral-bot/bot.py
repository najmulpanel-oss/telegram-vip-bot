import logging
import urllib.parse
import os
import asyncio
import time
import hmac
from collections import defaultdict
from datetime import datetime
from telegram import (
    Update,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    ReplyKeyboardRemove,
    BotCommand,
)
from telegram.constants import ParseMode, ChatMemberStatus
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ChatMemberHandler,
    ContextTypes,
    filters,
)

import config
import database

# Configure logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# --- ANTI-ATTACK & FLOOD DEFENSE SUBSYSTEM ---
USER_REQUEST_TIMES = defaultdict(list)
BANNED_UNTIL = {}
LOGIN_ATTEMPTS = defaultdict(list)
LOCKED_UNTIL = {}

def is_rate_limited(user_id: int, max_rate: int = 5, window_seconds: float = 3.0) -> bool:
    """
    Flood / Anti-DDoS rate limiter.
    Limits regular users to max 5 actions within 3 seconds.
    Temporarily bans abusers for 15 seconds.
    Owner (8884471241) and Admins are always exempt.
    """
    if str(user_id) == "8884471241" or database.is_admin(user_id):
        return False

    now = time.time()
    if user_id in BANNED_UNTIL:
        if now < BANNED_UNTIL[user_id]:
            return True
        else:
            del BANNED_UNTIL[user_id]

    timestamps = USER_REQUEST_TIMES[user_id]
    timestamps = [t for t in timestamps if now - t < window_seconds]
    timestamps.append(now)
    USER_REQUEST_TIMES[user_id] = timestamps

    if len(timestamps) > max_rate:
        BANNED_UNTIL[user_id] = now + 15
        logger.warning(f"Rate limit triggered for user {user_id}. Throttled for 15 seconds.")
        return True

    return False

def check_login_lockout(user_id: int) -> tuple[bool, int]:
    """
    Checks if a user is currently locked out from admin secret login.
    Returns (is_locked, remaining_minutes).
    """
    now = time.time()
    if user_id in LOCKED_UNTIL:
        if now < LOCKED_UNTIL[user_id]:
            remaining = int((LOCKED_UNTIL[user_id] - now) / 60) + 1
            return True, remaining
        else:
            del LOCKED_UNTIL[user_id]
            LOGIN_ATTEMPTS[user_id].clear()
    return False, 0

def record_failed_login(user_id: int) -> int:
    """
    Records a failed admin secret code attempt.
    Locks user out for 30 minutes after 3 failures.
    """
    now = time.time()
    attempts = LOGIN_ATTEMPTS[user_id]
    attempts = [t for t in attempts if now - t < 900] # 15-min sliding window
    attempts.append(now)
    LOGIN_ATTEMPTS[user_id] = attempts
    if len(attempts) >= 3:
        LOCKED_UNTIL[user_id] = now + 1800 # 30 minutes lockout
    return len(attempts)

# Safe answer callback query
async def safe_answer(query, text: str = None, show_alert: bool = False):
    try:
        if text:
            await query.answer(text, show_alert=show_alert)
        else:
            await query.answer()
    except Exception:
        pass

# Visual progress bar generator
def get_progress_bar(current: int, total: int, length: int = 8) -> str:
    if total <= 0:
        return "🟩" * length
    ratio = min(max(current / total, 0.0), 1.0)
    filled = int(round(ratio * length))
    empty = length - filled
    return "🟩" * filled + "⬜" * empty

# Dynamic Join Verification Inline Keyboard
def get_join_channels_keyboard():
    groups = database.get_groups()
    g1 = groups["g1_name"].replace("👥 ", "").replace("📢 ", "").strip()
    g2 = groups["g2_name"].replace("👥 ", "").replace("📢 ", "").strip()
    keyboard = [
        [
            InlineKeyboardButton(f"📢 {g1}", url=groups["g1_url"]),
            InlineKeyboardButton(f"💬 {g2}", url=groups["g2_url"])
        ],
        [InlineKeyboardButton("⚡️ Verify Membership", callback_data="check_joined")]
    ]
    return InlineKeyboardMarkup(keyboard)

# Main Dashboard Inline Keyboard
def get_dashboard_inline_keyboard(bot_username: str, user_id: int):
    ref_link = f"https://t.me/{bot_username}?start=ref_{user_id}"
    share_quote = f"🔥 Join now and get exclusive VIP Access & Password for FREE!\n👉 Link: {ref_link}"
    share_url = f"https://t.me/share/url?url={urllib.parse.quote(ref_link)}&text={urllib.parse.quote(share_quote)}"
    groups = database.get_groups()
    g1 = groups["g1_name"].replace("👥 ", "").replace("📢 ", "").strip()
    g2 = groups["g2_name"].replace("👥 ", "").replace("📢 ", "").strip()

    keyboard = [
        [
            InlineKeyboardButton(f"📢 {g1}", url=groups["g1_url"]),
            InlineKeyboardButton(f"💬 {g2}", url=groups["g2_url"])
        ],
        [
            InlineKeyboardButton("⚡️ Verify Membership", callback_data="check_joined")
        ],
        [
            InlineKeyboardButton("🔑 Get Key", callback_data="get_key"),
            InlineKeyboardButton("📤 Share Link", url=share_url)
        ],
        [
            InlineKeyboardButton("🔄 Refresh Dashboard", callback_data="refresh_dashboard")
        ]
    ]
    if database.is_admin(user_id):
        keyboard.append([InlineKeyboardButton("⚙️ Admin Console", callback_data="admin_center")])

    return InlineKeyboardMarkup(keyboard)

# Product Selection Keyboard for Users
def get_product_selection_keyboard(products, verified: int):
    keyboard = []
    for p in products:
        status_icon = "🔓" if verified >= p["required_referrals"] else "🔒"
        btn_text = f"{status_icon} {p['name']} ({p['required_referrals']} Refs)"
        keyboard.append([InlineKeyboardButton(btn_text, callback_data=f"view_product:{p['id']}")])
    keyboard.append([InlineKeyboardButton("🔙 Back to Dashboard", callback_data="refresh_dashboard")])
    return InlineKeyboardMarkup(keyboard)

# Admin Main Inline Keyboard (Screenshot 1: Stock & Group Management)
def get_admin_inline_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📦 View Key Stock", callback_data="admin_stock_view"),
            InlineKeyboardButton("➕ Add Keys", callback_data="admin_add_keys_prompt")
        ],
        [
            InlineKeyboardButton("🗑 Remove Stock", callback_data="admin_del_stock_menu"),
            InlineKeyboardButton("⚙️ Group Setup", callback_data="admin_manage_groups")
        ],
        [
            InlineKeyboardButton("🎯 Referral Target", callback_data="admin_setref_menu"),
            InlineKeyboardButton("🖼 Change Banner", callback_data="admin_setpic_info")
        ],
        [
            InlineKeyboardButton("📢 Broadcast Message", callback_data="admin_broadcast_info"),
            InlineKeyboardButton("🧪 Test Verification", callback_data="admin_test_groups")
        ],
        [
            InlineKeyboardButton("👥 User List", callback_data="admin_recent_users"),
            InlineKeyboardButton("💾 Backup Database", callback_data="admin_download_backup")
        ],
        [
            InlineKeyboardButton("🔐 Admin Secret Code", callback_data="admin_code_info"),
            InlineKeyboardButton("🔄 Refresh Console", callback_data="admin_refresh")
        ],
        [
            InlineKeyboardButton("🔙 Back to Dashboard", callback_data="refresh_dashboard")
        ]
    ])

# Channel ID Cache for fast and reliable API calls
CHAT_ID_CACHE = {
    "@PANELSTOREWORLD": -1001838981516,
    "@stmodofficial": -1003922114600,
}

# Helper to verify channel membership with Telegram API
async def is_user_member(bot, chat_target: str, user_id: int):
    if not chat_target:
        return True, "NO_TARGET"

    target = chat_target
    if str(target) in CHAT_ID_CACHE:
        target = CHAT_ID_CACHE[str(target)]
    elif str(target).startswith("@"):
        try:
            chat_obj = await bot.get_chat(target)
            if chat_obj and chat_obj.id:
                CHAT_ID_CACHE[str(target)] = chat_obj.id
                target = chat_obj.id
        except Exception:
            pass

    try:
        member = await bot.get_chat_member(chat_id=target, user_id=user_id)
        status_str = str(member.status).lower().replace("chatmemberstatus.", "")
        if status_str in ["member", "administrator", "creator", "owner"]:
            return True, "OK"
        if status_str == "restricted" and getattr(member, 'is_member', False):
            return True, "OK"
        if status_str in ["left", "kicked"]:
            return False, "NOT_MEMBER"
        return False, "NOT_MEMBER"
    except Exception as e:
        err = str(e).lower()
        if "user not found" in err or "participant" in err or "not in the chat" in err or "user_not_participant" in err:
            return False, "NOT_MEMBER"
        if "member list is inaccessible" in err or "chat_admin_required" in err or "not a member" in err or "admin" in err:
            return False, "BOT_ADMIN_REQUIRED"
        logger.warning(f"Error checking membership for user {user_id} in {chat_target}: {e}")
        return False, f"BOT_ERROR: {e}"

# Send instant notification alert to all Admins (Delivered to the new bot)
async def notify_admins(bot, text: str):
    conn = database.get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM admins")
    admin_rows = cursor.fetchall()
    conn.close()

    admin_ids = set([r["user_id"] for r in admin_rows] + [8884471241])

    extra_bot = None
    if getattr(config, "LOG_BOT_TOKEN", None):
        try:
            from telegram import Bot as ExtraBot
            extra_bot = ExtraBot(config.LOG_BOT_TOKEN)
        except Exception as e:
            logger.warning(f"Could not initialize ExtraBot: {e}")

    for aid in admin_ids:
        # Deliver to the new bot (psvarify_bot) so it appears in that bot's chat!
        if extra_bot:
            try:
                await extra_bot.send_message(chat_id=aid, text=text, parse_mode=ParseMode.MARKDOWN)
            except Exception:
                try:
                    await extra_bot.send_message(chat_id=aid, text=text)
                except Exception as e:
                    logger.warning(f"Could not send log via new bot to {aid}: {e}")

        # Also send via main bot if possible
        try:
            await bot.send_message(chat_id=aid, text=text, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            try:
                await bot.send_message(chat_id=aid, text=text)
            except Exception:
                pass

# Active Sync Check: Check if invited referrals left groups
async def sync_referrer_active_members(bot, referrer_id: int):
    try:
        ref_user_ids = database.get_verified_referral_user_ids(referrer_id)
        if not ref_user_ids:
            return
        groups = database.get_groups()
        g1_id = groups["g1_id"]
        g2_id = groups["g2_id"]

        for uid in ref_user_ids:
            ok1, _ = await is_user_member(bot, g1_id, uid)
            ok2, _ = await is_user_member(bot, g2_id, uid)
            if not ok1 or not ok2:
                ref_id, was_verified = database.revoke_user_membership(uid)
                if was_verified:
                    logger.info(f"Sync check: User {uid} left required groups. Deducted 1 referral from referrer {referrer_id}.")
                    avail, _ = database.get_referral_stats(referrer_id)
                    try:
                        await bot.send_message(
                            chat_id=referrer_id,
                            text=(
                                f"⚠️ **Referral Deducted (-1)**\n\n"
                                f"A member you invited (ID: `{uid}`) has left one of our official groups/channels.\n"
                                f"📉 **1 referral has been deducted from your account.**\n"
                                f"💰 Your Current Available Balance: **{avail}** Refs"
                            ),
                            parse_mode=ParseMode.MARKDOWN
                        )
                    except Exception:
                        pass

                    admin_leave_alert = (
                        f"⚠️ **[MEMBER LEFT GROUP / -1 REFERRAL]**\n"
                        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                        f"🆔 **Member ID:** `{uid}`\n"
                        f"👥 **Referrer ID:** `{referrer_id}`\n"
                        f"📉 **Action:** Referral Revoked (-1)\n"
                        f"💰 **Referrer Balance Now:** `{avail}` Refs\n"
                        f"📅 **Time:** `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`"
                    )
                    await notify_admins(bot, admin_leave_alert)
    except Exception as e:
        logger.warning(f"Error in sync_referrer_active_members: {e}")

# Real-time Telegram Chat Member Status Handler
async def chat_member_update_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        result = update.chat_member
        if not result:
            return

        chat = result.chat
        user = result.new_chat_member.user
        new_status = result.new_chat_member.status
        new_status_str = str(new_status).lower().replace("chatmemberstatus.", "")

        if new_status_str in ["left", "kicked", "banned"]:
            referrer_id, was_verified = database.revoke_user_membership(user.id)
            if was_verified:
                logger.info(f"User {user.id} left chat {chat.title or chat.id}. Revoked referral for {referrer_id}.")
                if referrer_id:
                    avail, _ = database.get_referral_stats(referrer_id)
                    try:
                        await context.bot.send_message(
                            chat_id=referrer_id,
                            text=(
                                f"⚠️ **Referral Deducted (-1)**\n\n"
                                f"Your invited friend **{user.first_name}** left {chat.title or 'one of our channels'}.\n"
                                f"📉 **1 referral has been deducted from your account.**\n"
                                f"💰 Remaining Available Referrals: **{avail}**"
                            ),
                            parse_mode=ParseMode.MARKDOWN
                        )
                    except Exception:
                        pass

                admin_leave_alert = (
                    f"⚠️ **[MEMBER LEFT GROUP / -1 REFERRAL]**\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"👤 **User:** {user.first_name}\n"
                    f"🆔 **User ID:** `{user.id}`\n"
                    f"📢 **Left Channel:** {chat.title or chat.id}\n"
                    f"👥 **Referrer ID:** `{referrer_id or 'None'}`\n"
                    f"📉 **Action:** Referral Revoked (-1)\n"
                    f"📅 **Time:** `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`"
                )
                await notify_admins(context.bot, admin_leave_alert)
    except Exception as e:
        logger.warning(f"Error in chat_member_update_handler: {e}")

# Build Dashboard Card Text (Ultra Clean, Minimal & Aesthetic)
def build_dashboard_text(user, verified: int, pending: int, required: int, bot_username: str) -> str:
    ref_link = f"https://t.me/{bot_username}?start=ref_{user.id}"
    bar = get_progress_bar(verified, required, length=8)
    percent = int(min(100, (verified / required) * 100)) if required > 0 else 100
    remaining = max(0, required - verified)

    is_joined = database.is_user_joined_db(user.id)
    group_badge = "✅ Verified" if is_joined else "❌ Not Joined"

    full_stats = database.get_referral_full_stats(user.id)
    lifetime_refs = full_stats["total_verified"]
    spent_refs = full_stats["spent"]

    if verified >= required:
        status_badge = "🟢 Unlocked"
        target_note = f"🎉 **Target Reached!** Tap **'🔑 Get Key'** below to claim your VIP Key.\n*(Cost: {required} referrals)*"
    else:
        status_badge = "🔒 Locked"
        target_note = f"👉 **Invite {remaining} more friend(s)** to reach {required} referrals and unlock your VIP Key!"

    card = (
        f"✨ **VIP PANEL PORTAL** ✨\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 **Account:** `{user.first_name}`\n"
        f"🆔 **User ID:** `{user.id}`\n"
        f"🔰 **Access:** {status_badge}\n"
        f"📢 **Channels:** {group_badge}\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🎯 **Referral Progress:**\n"
        f"`[{bar}]` **{percent}%** ({verified}/{required})\n\n"
        f"• 🟢 **Available Balance:** `{verified}` Refs\n"
        f"• 🏆 **Lifetime Total:** `{lifetime_refs}` Refs (Spent: `{spent_refs}`)\n"
        f"• ⏳ **Pending (Unverified):** `{pending}`\n\n"
        f"{target_note}\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🔗 **Your Referral Link:**\n"
        f"`{ref_link}`\n\n"
        f"💡 _(Tap the link above to copy & share)_"
    )
    return card

# Send photo with fallback to text
async def send_card_message(bot, chat_id: int, text: str, reply_markup=None, photo_url: str = None):
    url = photo_url or database.get_banner_url()
    try:
        if url:
            return await bot.send_photo(
                chat_id=chat_id,
                photo=url,
                caption=text,
                reply_markup=reply_markup,
                parse_mode=ParseMode.MARKDOWN
            )
    except Exception as e:
        logger.warning(f"Failed to send photo: {e}, falling back to text")

    return await bot.send_message(
        chat_id=chat_id,
        text=text,
        reply_markup=reply_markup,
        parse_mode=ParseMode.MARKDOWN
    )

# /start Command
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if is_rate_limited(user.id):
        await update.message.reply_text("⚠️ **Slow down!** Please wait a few seconds before sending commands again.", parse_mode=ParseMode.MARKDOWN)
        return

    args = context.args

    referrer_id = None
    if args and len(args) > 0:
        param = args[0].strip()
        if param.startswith("ref_"):
            param = param[4:]
        if param.isdigit():
            referrer_id = int(param)

    # Register user in DB
    db_user, is_new = database.get_or_create_user(
        user_id=user.id,
        username=user.username,
        first_name=user.first_name,
        referrer_id=referrer_id
    )

    if referrer_id and is_new:
        ref_user = database.get_user_details(referrer_id)
        u_ref = ref_user.get("user", {}) if ref_user else {}
        ref_name = u_ref.get("first_name", f"ID: {referrer_id}")
        ref_uname = f"@{u_ref.get('username')}" if u_ref.get("username") else "N/A"
        user_uname = f"@{user.username}" if user.username else "N/A"

        admin_ref_alert = (
            f"🔔 **[নতুন রেফারেল এন্ট্রি (Pending)]**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"👤 **নতুন ইউজার:** {user.first_name}\n"
            f"🆔 **ইউজার আইডি:** `{user.id}`\n"
            f"🔗 **ইউজারনেম:** {user_uname}\n\n"
            f"👥 **কার রেফারে এসেছে:**\n"
            f"• রেফারার নাম: **{ref_name}**\n"
            f"• রেফারার আইডি: `{referrer_id}`\n"
            f"• রেফারার ইউজারনেম: {ref_uname}\n\n"
            f"⏳ **স্ট্যাটাস:** পেন্ডিং (এখনো গ্রুপ ভেরিফাই করেনি)\n"
            f"📅 **সময়:** `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`"
        )
        await notify_admins(context.bot, admin_ref_alert)

    required = database.get_required_referrals()
    me = await context.bot.get_me()

    # If already verified
    if db_user and db_user["joined_groups"]:
        await sync_referrer_active_members(context.bot, user.id)
        verified, pending = database.get_referral_stats(user.id)
        card_text = build_dashboard_text(user, verified, pending, required, me.username)
        await send_card_message(
            context.bot,
            user.id,
            card_text,
            reply_markup=get_dashboard_inline_keyboard(me.username, user.id)
        )
        return

    # First-time / Unverified user
    welcome_banner = (
        f"✨ **VIP PANEL ACCESS PORTAL** ✨\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👋 Welcome, **{user.first_name}**!\n\n"
        f"Unlock your **Exclusive VIP Access & Passwords** in 3 simple steps:\n\n"
        f"1️⃣ Join both official channels below\n"
        f"2️⃣ Tap **'⚡️ Verify Membership'** to activate account\n"
        f"3️⃣ Invite friends with your referral link to claim your **VIP Key**!\n\n"
        f"👇 **Join both channels below to get started:**"
    )

    await send_card_message(
        context.bot,
        user.id,
        welcome_banner,
        reply_markup=get_join_channels_keyboard()
    )

# Verification Callback (Strict Telegram Verification)
async def check_joined_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user = query.from_user
    bot = context.bot

    if is_rate_limited(user.id):
        await safe_answer(query, "⚠️ Slow down! Please wait 2 seconds before tapping again.", show_alert=True)
        return

    groups = database.get_groups()

    # Verify Group 1
    ok1, reason1 = await is_user_member(bot, groups["g1_id"], user.id)
    if not ok1:
        if "BOT_ERROR" in reason1 or reason1 == "BOT_ADMIN_REQUIRED":
            await safe_answer(
                query,
                f"⚠️ Error: Bot is not an Admin in {groups['g1_name']}!\nPlease make @freepanelworld_bot an Admin in the channel.",
                show_alert=True
            )
            return
        await safe_answer(
            query,
            f"❌ Verification Incomplete!\n\nYou have not joined {groups['g1_name']} yet.\nPlease join the channel first, then tap Verify!",
            show_alert=True
        )
        return

    # Verify Group 2
    ok2, reason2 = await is_user_member(bot, groups["g2_id"], user.id)
    if not ok2:
        if "BOT_ERROR" in reason2 or reason2 == "BOT_ADMIN_REQUIRED":
            await safe_answer(
                query,
                f"⚠️ Error: Bot is not an Admin in {groups['g2_name']}!\nPlease make @freepanelworld_bot an Admin in the group.",
                show_alert=True
            )
            return
        await safe_answer(
            query,
            f"❌ Verification Incomplete!\n\nYou have not joined {groups['g2_name']} yet.\nPlease join the group first, then tap Verify!",
            show_alert=True
        )
        return

    # User successfully verified in BOTH channels!
    is_newly_joined, referrer_id, ref_count = database.mark_user_joined(user.id)
    required = database.get_required_referrals()

    # Notify referrer
    if is_newly_joined and referrer_id:
        try:
            name_display = user.first_name or "Friend"
            ref_bar = get_progress_bar(ref_count, required, 6)
            ref_notify = (
                f"🎉 **New Successful Referral!**\n\n"
                f"👤 **{name_display}** has joined the required groups via your invitation link.\n"
                f"📊 Your Total Referrals: **{ref_count} / {required}**\n"
                f"`[{ref_bar}]`\n"
            )
            await bot.send_message(
                chat_id=referrer_id,
                text=ref_notify,
                parse_mode=ParseMode.MARKDOWN
            )

            # Check if referrer unlocked the password!
            if ref_count >= required:
                congrats_card = (
                    f"🏆 **CONGRATULATIONS! TARGET MET!** 🏆\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"You have reached **{ref_count} verified referrals**! ✨\n\n"
                    f"Tap **'🔑 Get Key'** on your dashboard or send `/getkey` to reveal your VIP Password!"
                )
                await bot.send_message(
                    chat_id=referrer_id,
                    text=congrats_card,
                    parse_mode=ParseMode.MARKDOWN
                )
        except Exception as e:
            logger.warning(f"Referrer notification error: {e}")

    user_uname = f"@{user.username}" if user.username else "N/A"
    if referrer_id:
        ref_user = database.get_user_details(referrer_id)
        u_ref = ref_user["user"] if ref_user else {}
        r_name = u_ref.get("first_name", f"ID: {referrer_id}")
        r_uname = f"@{u_ref.get('username')}" if u_ref.get("username") else "N/A"
        ref_info = (
            f"• রেফারার নাম: {r_name}\n"
            f"• রেফারার আইডি: `{referrer_id}`\n"
            f"• রেফারার ইউজারনেম: {r_uname}\n"
            f"• রেফারারের মোট ভেরিফাইড সংখ্যা: `{ref_count}` টি"
        )
    else:
        ref_info = "• কোনো রেফারেল নেই (সরাসরি যুক্ত হয়েছে)"

    status_tag = "নতুন ইউজার ভেরিফাইড" if is_newly_joined else "ইউজার ভেরিফিকেশন সক্রিয়"

    admin_verify_alert = (
        f"✅ **[{status_tag} (Joined Groups)]**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 **ইউজার নাম:** {user.first_name}\n"
        f"🆔 **ইউজার আইডি:** `{user.id}`\n"
        f"🔗 **ইউজারনেম:** {user_uname}\n\n"
        f"👥 **রেফারেল তথ্য:**\n"
        f"{ref_info}\n\n"
        f"🔰 **স্ট্যাটাস:** গ্রুপ ১ ও ২ ভেরিফাইড ✅\n"
        f"📅 **সময়:** `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`"
    )
    await notify_admins(bot, admin_verify_alert)

    if is_newly_joined:
        await safe_answer(query, "🎉 Verification Successful!\nYou are now verified in both channels.", show_alert=True)
    else:
        await safe_answer(query, "✅ You are already verified and an active member of both channels!", show_alert=True)

    me = await bot.get_me()
    verified, pending = database.get_referral_stats(user.id)
    card_text = build_dashboard_text(user, verified, pending, required, me.username)
    keyboard = get_dashboard_inline_keyboard(me.username, user.id)

    try:
        if query.message.photo:
            await query.edit_message_caption(
                caption=card_text,
                reply_markup=keyboard,
                parse_mode=ParseMode.MARKDOWN
            )
        else:
            await query.edit_message_text(
                text=card_text,
                reply_markup=keyboard,
                parse_mode=ParseMode.MARKDOWN
            )
    except Exception as e:
        logger.warning(f"Failed to edit message in check_joined: {e}")
        await send_card_message(
            bot,
            user.id,
            card_text,
            reply_markup=keyboard
        )

# One-click VIP Key Retrieval Action
async def get_key_action(update: Update, context: ContextTypes.DEFAULT_TYPE, is_callback: bool = False):
    if is_callback:
        query = update.callback_query
        user = query.from_user
    else:
        query = None
        user = update.effective_user

    if is_rate_limited(user.id):
        if is_callback:
            await safe_answer(query, "⚠️ Slow down! Please wait a few seconds before trying again.", show_alert=True)
        else:
            await update.message.reply_text("⚠️ **Slow down!** Please wait a few seconds before trying again.", parse_mode=ParseMode.MARKDOWN)
        return

    # Strict check: is user in both groups?
    groups = database.get_groups()
    ok1, _ = await is_user_member(context.bot, groups["g1_id"], user.id)
    ok2, _ = await is_user_member(context.bot, groups["g2_id"], user.id)

    if not ok1 or not ok2:
        not_joined_name = groups["g1_name"] if not ok1 else groups["g2_name"]
        msg = (
            f"❌ আপনি এখনো {not_joined_name} এ জয়েন করেননি!\n\n"
            f"ভিআইপি পাসওয়ার্ড পেতে হলে অবশ্যই আগে দুটি গ্রুপেই জয়েন করে '⚡️ Verify Membership' বাটনে চাপ দিতে হবে।"
        )
        if is_callback:
            await safe_answer(query, msg, show_alert=True)
        else:
            await update.message.reply_text(msg)
        return

    db_user, _ = database.get_or_create_user(user.id, user.username, user.first_name)
    if not db_user or not db_user["joined_groups"]:
        msg = (
            f"❌ আপনার একাউন্ট এখনো ভেরিফাইড নয়!\n\n"
            f"আগে দুটি গ্রুপে জয়েন করে ড্যাশবোর্ডের '⚡️ Verify Membership' বাটনে চাপ দিন। নিজে ভেরিফাই সম্পন্ন না করলে পাসওয়ার্ড বা রেফারেল সক্রিয় হবে না।"
        )
        if is_callback:
            await safe_answer(query, msg, show_alert=True)
        else:
            await update.message.reply_text(msg)
        return

    # First sync check: ensure none of the verified referrals left the channels
    await sync_referrer_active_members(context.bot, user.id)

    verified, pending = database.get_referral_stats(user.id)
    required = database.get_required_referrals()

    if verified < required:
        needed = required - verified
        msg = (
            f"🔒 **Key Locked!**\n\n"
            f"To unlock a VIP Password, you need at least **{required} verified referrals**.\n"
            f"📊 **Available Referrals:** `{verified}/{required}`\n"
            f"⏳ **Pending Referrals:** `{pending}`\n\n"
            f"👉 Invite **{needed} more friend(s)** to join and verify to unlock your key!"
        )
        if is_callback:
            await safe_answer(query, msg, show_alert=True)
        else:
            await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN)
        return

    # Target achieved: claim key from stock or fallback
    password = database.claim_new_stock_key(user.id)
    # Deduct the referral points from user balance (Spendable balance system)
    database.spend_referrals(user.id, required)
    database.record_user_claim(user.id, 1)

    new_available, _ = database.get_referral_stats(user.id)
    full_stats = database.get_referral_full_stats(user.id)

    # Notify Admin & 2nd Bot about key claim
    user_uname = f"@{user.username}" if user.username else "N/A"
    admin_key_alert = (
        f"🔑 **[VIP KEY CLAIMED]**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 **User:** {user.first_name}\n"
        f"🆔 **User ID:** `{user.id}`\n"
        f"🔗 **Username:** {user_uname}\n"
        f"🔑 **Claimed Key:** `{password}`\n"
        f"📉 **Deducted Referrals:** `-{required}` Refs\n"
        f"💰 **Remaining Available:** `{new_available}` Refs\n"
        f"🏆 **Lifetime Total:** `{full_stats['total_verified']}` Refs\n"
        f"📅 **Time:** `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`"
    )
    await notify_admins(context.bot, admin_key_alert)

    key_msg = (
        f"🔑 **VIP KEY UNLOCKED** 🔑\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🎉 Congratulations, **{user.first_name}**!\n\n"
        f"🔐 **Your VIP Password / Access Key:**\n"
        f"`{password}`\n\n"
        f"📊 **Referral Balance Update:**\n"
        f"• Cost Deducted: `-{required}` Referrals\n"
        f"• Remaining Available: **`{new_available}`** Referrals\n"
        f"• Lifetime Total Referrals: `{full_stats['total_verified']}`\n\n"
        f"💡 _(Tap the key above to copy)_\n"
        f"🌐 **Panel Portal:** [Open Panel Website]({config.PANEL_URL})"
    )

    back_kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🌐 Open Panel Website", url=config.PANEL_URL)],
        [InlineKeyboardButton("🔙 Back to Dashboard", callback_data="refresh_dashboard")]
    ])

    if is_callback:
        await safe_answer(query, "🔓 Password Unlocked!", show_alert=False)
        try:
            await query.edit_message_caption(caption=key_msg, reply_markup=back_kb, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            try:
                await query.edit_message_text(text=key_msg, reply_markup=back_kb, parse_mode=ParseMode.MARKDOWN)
            except Exception:
                await query.message.reply_text(key_msg, reply_markup=back_kb, parse_mode=ParseMode.MARKDOWN)
    else:
        await update.message.reply_text(key_msg, reply_markup=back_kb, parse_mode=ParseMode.MARKDOWN)

async def get_key_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await get_key_action(update, context, is_callback=True)

async def getkey_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await get_key_action(update, context, is_callback=False)

# --- Key Stock Overview & Management (Screenshots 1, 2 & 3 in English) ---

def build_stock_overview_text() -> str:
    stats = database.get_stock_stats()
    recent = database.get_recent_available_keys(limit=10)

    keys_str = ""
    if not recent:
        keys_str = "⚠️ _No keys remaining in stock currently._\n"
    else:
        for i, k in enumerate(recent, 1):
            keys_str += f"{i}. `{k}`\n"

    msg = (
        f"📦 **Key Stock Overview:**\n"
        f"• **Available:** `{stats['available']}`\n"
        f"• **Used:** `{stats['used']}`\n"
        f"• **Total:** `{stats['total']}`\n\n"
        f"🔑 **Recent Available Keys:**\n"
        f"{keys_str}\n"
        f"➕ **To add new keys:** `/addkeys KEY1 KEY2` or tap button below\n"
        f"🗑 **To remove keys:** tap button below or write: `/delstock 5`"
    )
    return msg

def get_stock_inline_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("➕ Add Keys", callback_data="admin_add_keys_prompt"),
            InlineKeyboardButton("🗑 Remove Stock", callback_data="admin_del_stock_menu")
        ],
        [
            InlineKeyboardButton("🔄 Refresh", callback_data="admin_stock_view"),
            InlineKeyboardButton("🔙 Main Panel", callback_data="admin_center")
        ]
    ])

async def admin_stock_view_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not database.is_admin(query.from_user.id):
        await safe_answer(query, "⛔ Access Denied!", show_alert=True)
        return

    await safe_answer(query)
    msg = build_stock_overview_text()
    kb = get_stock_inline_keyboard()

    try:
        await query.edit_message_caption(caption=msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)
    except Exception:
        try:
            await query.edit_message_text(text=msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            await query.message.reply_text(msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)

async def stock_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    msg = build_stock_overview_text()
    kb = get_stock_inline_keyboard()
    await update.message.reply_text(msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)

async def admin_add_keys_prompt_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not database.is_admin(query.from_user.id):
        await safe_answer(query, "⛔ Access Denied!", show_alert=True)
        return

    context.user_data["awaiting_stock_keys"] = True
    await safe_answer(query)

    msg = (
        f"➕ **How to Add Keys (Key Stock):**\n\n"
        f"You can add multiple keys at once separated by space:\n\n"
        f"`/addkeys KEY-001 KEY-002 KEY-003`\n\n"
        f"Or in separate lines:\n"
        f"`/addkeys`\n"
        f"`XXXX-1111`\n"
        f"`YYYY-2222`\n"
        f"`ZZZZ-3333`\n\n"
        f"💡 **Or simply send your keys directly in this chat right now!**"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 Back to Key Stock", callback_data="admin_stock_view")]
    ])

    try:
        await query.edit_message_caption(caption=msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)
    except Exception:
        try:
            await query.edit_message_text(text=msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            await query.message.reply_text(msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)

async def admin_del_stock_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not database.is_admin(query.from_user.id):
        await safe_answer(query, "⛔ Access Denied!", show_alert=True)
        return

    await safe_answer(query)
    stats = database.get_stock_stats()

    msg = (
        f"🗑 **Remove Key Stock:**\n\n"
        f"• **Available Unused Keys:** `{stats['available']}`\n"
        f"• **Used Keys:** `{stats['used']}`\n\n"
        f"Select how many unused keys to remove below, or send command:\n"
        f"`/delstock <count>` (e.g. `/delstock 5`)\n"
        f"`/delstock all` (to clear all unused keys)"
    )
    kb = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🗑 Remove 1 Key", callback_data="del_stock_qty:1"),
            InlineKeyboardButton("🗑 Remove 5 Keys", callback_data="del_stock_qty:5"),
        ],
        [
            InlineKeyboardButton("⚠️ Clear All Unused", callback_data="del_stock_all")
        ],
        [
            InlineKeyboardButton("🔙 Back to Key Stock", callback_data="admin_stock_view")
        ]
    ])

    try:
        await query.edit_message_caption(caption=msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)
    except Exception:
        try:
            await query.edit_message_text(text=msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            await query.message.reply_text(msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)

async def del_stock_qty_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not database.is_admin(query.from_user.id):
        return

    qty = int(query.data.split(":")[1])
    deleted = database.delete_stock_keys(qty)
    await safe_answer(query, f"🗑 Removed {deleted} key(s) from stock!", show_alert=True)
    await admin_stock_view_callback(update, context)

async def del_stock_all_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not database.is_admin(query.from_user.id):
        return

    deleted = database.clear_all_unused_stock()
    await safe_answer(query, f"⚠️ Cleared {deleted} unused key(s) from stock!", show_alert=True)
    await admin_stock_view_callback(update, context)

async def addkeys_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    raw_text = update.message.text
    if raw_text.startswith("/addkeys"):
        raw_text = raw_text[8:].strip()

    keys = [k.strip() for k in raw_text.split() if k.strip()]
    if not keys:
        await update.message.reply_text(
            "➕ **How to Add Keys:**\n\n"
            "Usage:\n`/addkeys KEY-001 KEY-002 KEY-003`\n\n"
            "Or multi-line:\n`/addkeys\nKEY1\nKEY2\nKEY3`",
            parse_mode=ParseMode.MARKDOWN
        )
        return

    added = database.add_stock_keys(keys)
    stats = database.get_stock_stats()
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("📦 View Key Stock", callback_data="admin_stock_view")],
        [InlineKeyboardButton("🔙 Main Panel", callback_data="admin_center")]
    ])
    await update.message.reply_text(
        f"✅ **{added} Key(s) Added to Stock Successfully!**\n\n"
        f"📦 **Available Now:** `{stats['available']}`\n"
        f"📊 **Total Stock:** `{stats['total']}`",
        reply_markup=kb,
        parse_mode=ParseMode.MARKDOWN
    )

async def delstock_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    if not context.args:
        await update.message.reply_text(
            "Usage: `/delstock <count>` (e.g. `/delstock 5`)\nOr `/delstock all` to clear all unused keys.",
            parse_mode=ParseMode.MARKDOWN
        )
        return

    arg = context.args[0].lower().strip()
    if arg == "all":
        deleted = database.clear_all_unused_stock()
    elif arg.isdigit():
        deleted = database.delete_stock_keys(int(arg))
    else:
        await update.message.reply_text("Usage: `/delstock <number>` (e.g. `/delstock 5`) or `/delstock all`")
        return

    stats = database.get_stock_stats()
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("📦 View Key Stock", callback_data="admin_stock_view")],
        [InlineKeyboardButton("🔙 Main Panel", callback_data="admin_center")]
    ])
    await update.message.reply_text(
        f"🗑 **{deleted} Unused Key(s) Removed!**\n\n"
        f"📦 **Available Remaining:** `{stats['available']}`\n"
        f"📊 **Total Stock:** `{stats['total']}`",
        reply_markup=kb,
        parse_mode=ParseMode.MARKDOWN
    )

async def admin_manage_pass_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await admin_stock_view_callback(update, context)

async def admin_prompt_password_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not database.is_admin(query.from_user.id):
        await safe_answer(query, "⛔ Access Denied!", show_alert=True)
        return

    context.user_data["awaiting_password"] = True
    await safe_answer(query)

    msg = (
        f"⌨️ **Enter New VIP Password:**\n\n"
        f"Simply send your new password in this chat now.\n\n"
        f"💡 Format options:\n"
        f"• Just password: `VIP_PASS_2026`\n"
        f"• Or with name & referrals: `Panel VIP | PASS123 | 2`\n\n"
        f"_(Whatever you send will be directly saved into the bot)_"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("❌ Cancel", callback_data="admin_cancel_password")]
    ])
    await query.message.reply_text(msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)

async def admin_cancel_password_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    context.user_data["awaiting_password"] = False
    await safe_answer(query, "❌ Cancelled.")
    try:
        await query.message.delete()
    except Exception:
        pass
    await admin_manage_pass_callback(update, context)

async def admin_txt_guide_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await safe_answer(query)
    msg = (
        f"📄 **Password Text File (.txt) Upload Guide:**\n\n"
        f"1. Create a `.txt` file on your computer/phone (e.g. `passwords.txt`).\n"
        f"2. Write one password per line inside the file.\n"
        f"3. Send the file as a **Document / File** into this chat.\n\n"
        f"🚀 The bot will automatically read the file, import all passwords, and show them in your password list!"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 Back to Password Manager", callback_data="admin_manage_pass")]
    ])
    try:
        await query.edit_message_caption(caption=msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)
    except Exception:
        await query.message.reply_text(msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)

async def setpassword_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    if not context.args:
        curr_pass = database.get_secret_password()
        await update.message.reply_text(
            f"🔐 **Current VIP Password:** `{curr_pass}`\n\n"
            f"To change password, use:\n`/setpassword <new_password>`",
            parse_mode=ParseMode.MARKDOWN
        )
        return

    new_pass = " ".join(context.args).strip()
    database.set_secret_password(new_pass)
    await update.message.reply_text(f"✅ Secret VIP Password successfully updated to:\n`{new_pass}`", parse_mode=ParseMode.MARKDOWN)

# Callback: Product Store & Claim
async def claim_password_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user = query.from_user
    verified, _ = database.get_referral_stats(user.id)
    products = database.get_all_products(only_active=True)

    if not products:
        await safe_answer(query, "No products available currently.", show_alert=True)
        return

    await safe_answer(query)

    store_text = (
        f"┏━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        f"   🎁 **VIP PRODUCT & REWARD STORE** 🎁\n"
        f"┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        f"👤 **Account:** `{user.first_name}`\n"
        f"📊 **Your Verified Referrals:** `{verified}`\n\n"
        f"Select an available product below to unlock its secret password / access key:"
    )

    try:
        await query.edit_message_caption(
            caption=store_text,
            reply_markup=get_product_selection_keyboard(products, verified),
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception:
        try:
            await query.edit_message_text(
                text=store_text,
                reply_markup=get_product_selection_keyboard(products, verified),
                parse_mode=ParseMode.MARKDOWN
            )
        except Exception:
            await query.message.reply_text(
                store_text,
                reply_markup=get_product_selection_keyboard(products, verified),
                parse_mode=ParseMode.MARKDOWN
            )

# Callback: View Individual Product
async def view_product_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user = query.from_user
    data = query.data

    prod_id = int(data.split(":")[1])
    product = database.get_product(prod_id)

    if not product or not product["is_active"]:
        await safe_answer(query, "⚠️ This product is no longer active.", show_alert=True)
        return

    verified, _ = database.get_referral_stats(user.id)
    req = product["required_referrals"]
    me = await context.bot.get_me()
    ref_link = f"https://t.me/{me.username}?start=ref_{user.id}"

    if verified >= req:
        database.record_user_claim(user.id, prod_id)
        await safe_answer(query, "🔓 Product Unlocked!")

        unlocked_msg = (
            f"┏━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
            f"   🔓 **PRODUCT UNLOCKED!** 🔓\n"
            f"┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            f"📦 **Product:** {product['name']}\n"
            f"📝 **Description:** {product['description'] or 'VIP Access'}\n\n"
            f"🔑 **Secret Password / Key:**\n"
            f"`{product['secret_password']}`\n\n"
            f"🌐 **Panel Login:** [Click to Open Panel]({config.PANEL_URL})\n\n"
            f"💡 _(Tap the password to copy)_"
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 Back to Product Store", callback_data="claim_password")],
            [InlineKeyboardButton("🌐 Open Panel Website", url=config.PANEL_URL)]
        ])
    else:
        needed = req - verified
        bar = get_progress_bar(verified, req, 6)
        await safe_answer(query, f"🔒 Locked! You need {needed} more referral(s).", show_alert=True)

        unlocked_msg = (
            f"┏━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
            f"   🔒 **LOCKED: {product['name']}** 🔒\n"
            f"┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            f"📝 **Description:** {product['description'] or 'VIP Access'}\n"
            f"🎯 **Required Referrals:** `{req}`\n"
            f"📊 **Your Verified Referrals:** `{verified}`\n"
            f"📈 **Progress:** `[{bar}]` ({verified}/{req})\n\n"
            f"⏳ You need **{needed} more referral(s)** to unlock this specific item!\n\n"
            f"🔗 **Your Referral Link:**\n"
            f"`{ref_link}`"
        )
        share_quote = f"🔥 Join now and get exclusive VIP Panel Access & Password for FREE!\n👉 Link: {ref_link}"
        share_url = f"https://t.me/share/url?url={urllib.parse.quote(ref_link)}&text={urllib.parse.quote(share_quote)}"

        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("📤 Share Link with Friends", url=share_url)],
            [InlineKeyboardButton("🔙 Back to Product Store", callback_data="claim_password")]
        ])

    try:
        await query.edit_message_caption(caption=unlocked_msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)
    except Exception:
        try:
            await query.edit_message_text(text=unlocked_msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            await query.message.reply_text(unlocked_msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)

# Callback: Referral History
async def ref_history_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user = query.from_user
    await safe_answer(query)

    history = database.get_referral_list(user.id, limit=10)
    verified, pending = database.get_referral_stats(user.id)
    required = database.get_required_referrals()

    if not history:
        text = (
            f"📊 **Your Referral List is Empty!**\n\n"
            f"You haven't referred anyone yet. Share your personal link to start unlocking your VIP products!"
        )
    else:
        text = (
            f"📊 **Your Recent Referrals (Last 10):**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        )
        for i, ref in enumerate(history, 1):
            status = "✅ Verified" if ref["is_verified"] else "⏳ Pending"
            name = ref["first_name"] or "Telegram User"
            date_str = ref["created_at"][:16]
            text += f"{i}. **{name}** — {status} ({date_str})\n"

        text += (
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📈 Verified: **{verified}** | Pending: **{pending}** | Tier 1 Target: **{required}**"
        )

    await query.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

# Callback: Leaderboard
async def leaderboard_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await safe_answer(query)

    top_users = database.get_leaderboard(limit=10)
    if not top_users:
        text = "🏆 **Leaderboard is currently empty!**\nBe the first to invite friends and top the rankings!"
    else:
        medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
        text = (
            f"┏━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
            f"   🏆 **TOP REFERRAL LEADERBOARD** 🏆\n"
            f"┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        )
        for i, u in enumerate(top_users):
            medal = medals[i] if i < len(medals) else f"{i+1}."
            name = u["first_name"] or "User"
            count = u["ref_count"]
            text += f"{medal} **{name}** — `{count}` Referrals\n"
        text += "\n🔥 Increase your referrals to climb to the top!"

    await query.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

# Callback: Refresh Dashboard
async def refresh_dashboard_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user = query.from_user
    me = await context.bot.get_me()
    await safe_answer(query, "🔄 Dashboard Refreshed!")

    await sync_referrer_active_members(context.bot, user.id)
    verified, pending = database.get_referral_stats(user.id)
    required = database.get_required_referrals()
    card_text = build_dashboard_text(user, verified, pending, required, me.username)

    try:
        await query.edit_message_caption(
            caption=card_text,
            reply_markup=get_dashboard_inline_keyboard(me.username, user.id),
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception:
        try:
            await query.edit_message_text(
                text=card_text,
                reply_markup=get_dashboard_inline_keyboard(me.username, user.id),
                parse_mode=ParseMode.MARKDOWN
            )
        except Exception:
            pass

# Callback: Admin Center
async def admin_center_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user = query.from_user
    if not database.is_admin(user.id):
        await safe_answer(query, "⛔ Access Denied! Admins only.", show_alert=True)
        return

    await safe_answer(query)
    stats = database.get_total_stats()
    stock_stats = database.get_stock_stats()
    required = database.get_required_referrals()
    banner = database.get_banner_url()
    groups = database.get_groups()

    admin_msg = (
        f"⚙️ **ADMIN CONTROL CENTER**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👥 **Total Registered Users:** `{stats['total_users']}`\n"
        f"✅ **Verified Users (Joined Groups):** `{stats['joined_users']}`\n"
        f"🎉 **Total Referrals Completed:** `{stats['completed_referrals']}`\n"
        f"📦 **Key Stock Available:** `{stock_stats['available']}` (Used: `{stock_stats['used']}`)\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🔗 **Group 1:** [{groups['g1_name']}]({groups['g1_url']})\n"
        f"🔗 **Group 2:** [{groups['g2_name']}]({groups['g2_url']})\n"
        f"🎯 **Default Referral Target:** `{required}` Refs\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👇 Select an action from the options below:"
    )

    try:
        await query.edit_message_caption(
            caption=admin_msg,
            reply_markup=get_admin_inline_keyboard(),
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception:
        await query.message.reply_text(
            admin_msg,
            reply_markup=get_admin_inline_keyboard(),
            parse_mode=ParseMode.MARKDOWN
        )

# Callback: Admin Manage Products (Unified with Password Manager)
async def admin_manage_prods_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await admin_manage_pass_callback(update, context)

# Callback: Admin Manage Groups
async def admin_manage_groups_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not database.is_admin(query.from_user.id):
        await safe_answer(query, "⛔ Access Denied!", show_alert=True)
        return

    await safe_answer(query)
    groups = database.get_groups()

    msg = (
        f"🔗 **GROUPS & CHANNELS MANAGEMENT**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"1️⃣ **Group / Channel 1:**\n"
        f"   • Name: `{groups['g1_name']}`\n"
        f"   • URL: {groups['g1_url']}\n"
        f"   • Chat ID: `{groups['g1_id'] or 'None'}`\n\n"
        f"2️⃣ **Group / Channel 2:**\n"
        f"   • Name: `{groups['g2_name']}`\n"
        f"   • URL: {groups['g2_url']}\n"
        f"   • Chat ID: `{groups['g2_id'] or 'None'}`\n\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🛠 **How to change group links:**\n\n"
        f"👉 To change Group 1, send:\n"
        f"`/setgroup1 Name | Link`\n"
        f"*(Example: `/setgroup1 VIP Channel | https://t.me/PANELSTOREWORLD`)*\n\n"
        f"👉 To change Group 2, send:\n"
        f"`/setgroup2 Name | Link`\n"
        f"*(Example: `/setgroup2 VIP Group | https://t.me/stmodofficial`)*\n\n"
        f"💡 *Remember to promote the bot as Admin in both channels!*"
    )

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🧪 Test Verification", callback_data="admin_test_groups")],
        [InlineKeyboardButton("🔙 Back to Admin Console", callback_data="admin_center")]
    ])

    try:
        await query.edit_message_caption(caption=msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)
    except Exception:
        await query.message.reply_text(msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)

# Verification Diagnostic Report
async def generate_group_test_report(bot):
    groups = database.get_groups()
    report = "🧪 **GROUP VERIFICATION TEST REPORT**\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n"

    for i, (name, target, url) in enumerate([
        (groups["g1_name"], groups["g1_id"], groups["g1_url"]),
        (groups["g2_name"], groups["g2_id"], groups["g2_url"])
    ], 1):
        report += f"**{i}️⃣ {name}:**\n• URL: {url}\n• Target: `{target or 'None'}`\n"
        if not target:
            report += "• Status: ⚠️ No username or Chat ID configured. Membership cannot be verified.\n\n"
            continue
        try:
            bot_me = await bot.get_me()
            bot_member = await bot.get_chat_member(chat_id=target, user_id=bot_me.id)
            if bot_member.status in [ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER]:
                report += "• Status: ✅ **ACTIVE & WORKING!** (Bot is Admin in this channel)\n\n"
            else:
                report += f"• Status: ❌ **Bot is only a '{bot_member.status}'**. Please make @{bot_me.username} an **Admin**!\n\n"
        except Exception as e:
            report += f"• Status: ❌ **Error:** {e}\n👉 Make sure @freepanelworld_bot is added as an **Admin** in this channel/group!\n\n"

    report += "━━━━━━━━━━━━━━━━━━━━━━━━━━\n💡 *Tip: Telegram requires the bot to be an Admin in the channel/group to verify membership!*"
    return report

# Callback: Admin Test Groups
async def admin_test_groups_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not database.is_admin(query.from_user.id):
        await safe_answer(query, "⛔ Access Denied!", show_alert=True)
        return

    await safe_answer(query, "Testing channel permissions...")
    report = await generate_group_test_report(context.bot)
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 Back to Admin Console", callback_data="admin_center")]
    ])
    await query.message.reply_text(report, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)

# Command: /testgroups
async def testgroups_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    status_msg = await update.message.reply_text("🔍 Testing channel permissions with Telegram API...")
    report = await generate_group_test_report(context.bot)
    await status_msg.edit_text(report, parse_mode=ParseMode.MARKDOWN)

# Callback: Admin Delete Product
async def admin_del_prod_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not database.is_admin(query.from_user.id):
        await safe_answer(query, "⛔ Access Denied!", show_alert=True)
        return

    prod_id = int(query.data.split(":")[1])
    database.delete_product(prod_id)
    await safe_answer(query, f"✅ Password #{prod_id} deleted successfully!", show_alert=True)
    await admin_manage_pass_callback(update, context)

# Callback: Admin Edit Pass Prompt
async def admin_edit_pass_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    prod_id = query.data.split(":")[1]
    await safe_answer(query)
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 Back to Password Manager", callback_data="admin_manage_pass")]
    ])
    await query.message.reply_text(
        f"✏️ **To change password for Product #{prod_id}:**\n\n"
        f"Copy and send the command with your new password:\n"
        f"`/setprodpass {prod_id} YOUR_NEW_PASSWORD`",
        reply_markup=kb,
        parse_mode=ParseMode.MARKDOWN
    )

# Callback: Admin Edit Ref Prompt
async def admin_edit_ref_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    prod_id = query.data.split(":")[1]
    await safe_answer(query)
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 Back to Password Manager", callback_data="admin_manage_pass")]
    ])
    await query.message.reply_text(
        f"🎯 **To change required referrals for Product #{prod_id}:**\n\n"
        f"Copy and send the command with the new referral target:\n"
        f"`/setprodref {prod_id} 3`",
        reply_markup=kb,
        parse_mode=ParseMode.MARKDOWN
    )

# Callback: Admin Add Product Guide
async def admin_add_guide_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await safe_answer(query)
    guide = (
        "➕ **How to Add a New Product:**\n\n"
        "Send the command in this exact format:\n"
        "`/addproduct Name | Password | Required_Refs | Description`\n\n"
        "**Example:**\n"
        "`/addproduct Free Fire Panel | VIP999 | 2 | 30 Days VIP Login Key`\n\n"
        "You can create as many products as you want!"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 Back to Password Manager", callback_data="admin_manage_pass")]
    ])
    await query.message.reply_text(guide, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)

# Callback: Admin Quick Ref Target Menu
async def admin_setref_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not database.is_admin(query.from_user.id):
        await safe_answer(query, "⛔ Access Denied!", show_alert=True)
        return

    await safe_answer(query)
    kb = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("1 Ref", callback_data="quick_ref:1"),
            InlineKeyboardButton("2 Refs", callback_data="quick_ref:2"),
            InlineKeyboardButton("3 Refs", callback_data="quick_ref:3"),
            InlineKeyboardButton("5 Refs", callback_data="quick_ref:5")
        ],
        [InlineKeyboardButton("🔙 Back to Admin Console", callback_data="admin_center")]
    ])
    await query.message.reply_text("🎯 **Select New Default Referral Target:**", reply_markup=kb, parse_mode=ParseMode.MARKDOWN)

# Callback: Quick Set Ref
async def quick_set_ref_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not database.is_admin(query.from_user.id):
        return
    num = int(query.data.split(":")[1])
    database.set_required_referrals(num)
    await safe_answer(query, f"✅ Default referral target set to {num}!", show_alert=True)
    await admin_center_callback(update, context)

async def admin_refresh_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await admin_center_callback(update, context)

async def admin_setpic_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await safe_answer(query)
    msg = (
        "🖼 **Change Banner Picture:**\n\n"
        "1️⃣ **Via Image URL:**\nSend: `/setpic https://example.com/banner.jpg`\n\n"
        "2️⃣ **Via Photo Upload:**\nSend any photo directly to this chat with caption `/setpic`\n\n"
        "💡 The dashboard banner will immediately update for all users!"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 Back to Admin Console", callback_data="admin_center")]
    ])
    await query.message.reply_text(msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)

async def admin_broadcast_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await safe_answer(query)
    msg = (
        "📢 **Broadcast Message to All Users:**\n\n"
        "• **Text Broadcast:**\nSend: `/broadcast Your message here...`\n\n"
        "• **Photo Broadcast:**\nSend any photo with caption `/broadcast Your announcement caption`\n\n"
        "🚀 The message will be delivered instantly to all registered users!"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 Back to Admin Console", callback_data="admin_center")]
    ])
    await query.message.reply_text(msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)

async def admin_code_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await safe_answer(query)
    code = database.get_admin_secret_code()
    msg = (
        f"🔐 **Admin Secret Login Code:**\n\n"
        f"Current Code: `{code}`\n\n"
        f"To change the code, send:\n"
        f"`/setlogincode <new_code>`\n\n"
        f"💡 Anyone who types `/login {code}` can access the Admin Console."
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 Back to Admin Console", callback_data="admin_center")]
    ])
    await query.message.reply_text(msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)

async def admin_recent_users_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not database.is_admin(query.from_user.id):
        await safe_answer(query, "⛔ Access Denied!", show_alert=True)
        return
    await safe_answer(query)

    users = database.get_recent_users(15)
    msg = (
        f"👥 **USER REFERRAL TRACKER (Recent Users):**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
    )
    if not users:
        msg += "No users found in database."
    else:
        for i, u in enumerate(users, 1):
            joined = "✅ Joined" if u["joined_groups"] else "❌ Unverified"
            name = u["first_name"] or "User"
            uid = u["user_id"]
            avail = u.get("available", 0)
            total = u.get("total_verified", 0)
            spent = u.get("spent", 0)
            pending = u.get("pending", 0)
            msg += (
                f"**{i}. {name}** (`{uid}`)\n"
                f"   • Status: {joined}\n"
                f"   • Referrals: **{avail} Avail** (Total: {total} | Spent: {spent} | Pend: {pending})\n"
                f"   • Details: `/user {uid}`\n\n"
            )

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔄 Refresh List", callback_data="admin_recent_users")],
        [InlineKeyboardButton("🔙 Back to Admin Console", callback_data="admin_center")]
    ])
    try:
        await query.edit_message_caption(caption=msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)
    except Exception:
        try:
            await query.edit_message_text(text=msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            await query.message.reply_text(msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)

async def users_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    users = database.get_recent_users(15)
    msg = (
        f"👥 **USER REFERRAL TRACKER (Recent Users):**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
    )
    if not users:
        msg += "No users found in database."
    else:
        for i, u in enumerate(users, 1):
            joined = "✅ Joined" if u["joined_groups"] else "❌ Unverified"
            name = u["first_name"] or "User"
            uid = u["user_id"]
            avail = u.get("available", 0)
            total = u.get("total_verified", 0)
            spent = u.get("spent", 0)
            pending = u.get("pending", 0)
            msg += (
                f"**{i}. {name}** (`{uid}`)\n"
                f"   • Status: {joined}\n"
                f"   • Referrals: **{avail} Avail** (Total: {total} | Spent: {spent} | Pend: {pending})\n"
                f"   • Details: `/user {uid}`\n\n"
            )

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 Back to Admin Console", callback_data="admin_center")]
    ])
    await update.message.reply_text(msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)

# --- Bot Command Handlers (Available in 3-dot Menu) ---

async def claim_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    verified, _ = database.get_referral_stats(user.id)
    products = database.get_all_products(only_active=True)

    store_text = (
        f"┏━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        f"   🎁 **VIP PRODUCT & REWARD STORE** 🎁\n"
        f"┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        f"👤 **Account:** `{user.first_name}`\n"
        f"📊 **Your Verified Referrals:** `{verified}`\n\n"
        f"Select an available product below to unlock its secret password / access key:"
    )
    await update.message.reply_text(
        store_text,
        reply_markup=get_product_selection_keyboard(products, verified),
        parse_mode=ParseMode.MARKDOWN
    )

async def refer_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    me = await context.bot.get_me()
    ref_link = f"https://t.me/{me.username}?start=ref_{user.id}"
    share_quote = f"🔥 Join now and get exclusive VIP Panel Access & Password for FREE!\n👉 Link: {ref_link}"
    share_url = f"https://t.me/share/url?url={urllib.parse.quote(ref_link)}&text={urllib.parse.quote(share_quote)}"

    inline_kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("📤 Share Directly to Friends / Groups", url=share_url)]
    ])

    msg = (
        f"🔗 **Your Personal Referral Link:**\n\n"
        f"`{ref_link}`\n\n"
        f"_(Tap the link above to copy)_\n\n"
        f"📌 Share with friends to unlock your VIP Passwords!"
    )
    await update.message.reply_text(msg, reply_markup=inline_kb, parse_mode=ParseMode.MARKDOWN)

async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    me = await context.bot.get_me()
    verified, pending = database.get_referral_stats(user.id)
    required = database.get_required_referrals()

    card_text = build_dashboard_text(user, verified, pending, required, me.username)
    await send_card_message(
        context.bot,
        user.id,
        card_text,
        reply_markup=get_dashboard_inline_keyboard(me.username, user.id)
    )

async def leaderboard_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    top_users = database.get_leaderboard(limit=10)
    if not top_users:
        text = "🏆 **Leaderboard is currently empty!**"
    else:
        medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
        text = (
            f"┏━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
            f"   🏆 **TOP REFERRAL LEADERBOARD** 🏆\n"
            f"┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        )
        for i, u in enumerate(top_users):
            medal = medals[i] if i < len(medals) else f"{i+1}."
            name = u["first_name"] or "User"
            count = u["ref_count"]
            text += f"{medal} **{name}** — `{count}` Referrals\n"
    await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    groups = database.get_groups()
    inline_kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("💬 Official Support", url=config.SUPPORT_URL)],
        [InlineKeyboardButton("🌐 Panel Website", url=config.PANEL_URL)]
    ])
    rules = (
        f"📌 **Rules & Guidelines:**\n\n"
        f"1️⃣ You must remain a member of both required channels:\n"
        f"   • {groups['g1_name']}\n"
        f"   • {groups['g2_name']}\n\n"
        f"2️⃣ Share your personal referral link with friends.\n"
        f"3️⃣ When they join and verify, your referral count increases by 1.\n"
        f"4️⃣ Claim multiple VIP products as you reach each referral target!\n\n"
        f"Need assistance? Contact our official support below."
    )
    await update.message.reply_text(rules, reply_markup=inline_kb, parse_mode=ParseMode.MARKDOWN)

# --- Secret Admin Login & Administration ---

async def login_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    # Anti-Shoulder-Surfing / Chat Security: delete secret code from chat history
    try:
        await update.message.delete()
    except Exception:
        pass

    # Brute-force protection lockout check
    is_locked, remaining = check_login_lockout(user.id)
    if is_locked:
        await update.message.reply_text(
            f"🚫 **Access Temporarily Blocked!**\n\n"
            f"Too many failed login attempts detected from your account.\n"
            f"Please wait **{remaining} minute(s)** before trying again.",
            parse_mode=ParseMode.MARKDOWN
        )
        return

    if not context.args:
        await update.message.reply_text("Usage: `/login <secret_code>`", parse_mode=ParseMode.MARKDOWN)
        return

    code_attempt = context.args[0].strip()
    actual_code = database.get_admin_secret_code()

    # Constant-time comparison to protect against timing attacks
    if hmac.compare_digest(code_attempt, actual_code):
        database.add_admin(user.id)
        if user.id in LOGIN_ATTEMPTS:
            del LOGIN_ATTEMPTS[user.id]
        await update.message.reply_text(
            f"👑 **Admin Access Granted!**\n\n"
            f"Welcome, **{user.first_name}**! You are now an authorized administrator.\n"
            f"Use `/admin` to open the full Admin Console.",
            parse_mode=ParseMode.MARKDOWN
        )
        # Notify owner & 2nd bot of successful admin authentication
        admin_login_alert = (
            f"🛡️ **[ADMIN LOGIN SUCCESSFUL]**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"👤 **Admin:** {user.first_name}\n"
            f"🆔 **User ID:** `{user.id}`\n"
            f"🔖 **Username:** @{user.username if user.username else 'N/A'}\n"
            f"📅 **Time:** `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`"
        )
        await notify_admins(context.bot, admin_login_alert)
    else:
        fails = record_failed_login(user.id)
        if fails >= 3:
            # Trigger High-Priority Security Alert to 2nd bot
            sec_alert = (
                f"🚨 **[SECURITY ALERT: BRUTE FORCE DETECTED]**\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                f"👤 **Suspicious User:** {user.first_name}\n"
                f"🆔 **User ID:** `{user.id}`\n"
                f"🔖 **Username:** @{user.username if user.username else 'N/A'}\n"
                f"⚠️ **Action:** Failed 3 admin secret code attempts.\n"
                f"🚫 **Penalty:** Locked out for 30 minutes.\n"
                f"📅 **Time:** `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`"
            )
            await notify_admins(context.bot, sec_alert)
            await update.message.reply_text(
                "🚨 **Access Blocked!**\n\nYou entered incorrect admin credentials 3 times. Your account has been locked out for 30 minutes.",
                parse_mode=ParseMode.MARKDOWN
            )
        else:
            left_attempts = 3 - fails
            await update.message.reply_text(
                f"❌ **Invalid admin secret code.**\n\n⚠️ Caution: {left_attempts} attempt(s) remaining before security lockout.",
                parse_mode=ParseMode.MARKDOWN
            )

# Command & Callback: Live Database Backup
async def backup_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    status_msg = await update.message.reply_text("⏳ Generating live database backup...")
    try:
        backup_path = database.create_backup()
        if not backup_path or not os.path.exists(backup_path):
            await status_msg.edit_text("❌ Database backup failed.")
            return

        file_size_kb = round(os.path.getsize(backup_path) / 1024, 2)
        caption = (
            f"💾 **LIVE DATABASE BACKUP** 💾\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📅 **Timestamp:** `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`\n"
            f"📊 **File Size:** `{file_size_kb} KB`\n"
            f"🛡️ **Integrity:** 100% Consistent (WAL Mode)\n\n"
            f"💡 Save this file. Even if the bot is stopped or deleted, you can restore all users, referrals, and passwords from this file!"
        )
        with open(backup_path, "rb") as f:
            await context.bot.send_document(
                chat_id=user.id,
                document=f,
                filename=os.path.basename(backup_path),
                caption=caption,
                parse_mode=ParseMode.MARKDOWN
            )
        await status_msg.delete()
    except Exception as e:
        logger.error(f"Backup command error: {e}")
        await status_msg.edit_text(f"❌ Backup failed: {e}")

async def admin_download_backup_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user = query.from_user
    if not database.is_admin(user.id):
        await safe_answer(query, "⛔ Access Denied!", show_alert=True)
        return

    await safe_answer(query, "⏳ Creating backup...", show_alert=False)
    backup_path = database.create_backup()
    if not backup_path or not os.path.exists(backup_path):
        await query.message.reply_text("❌ Database backup failed.")
        return

    file_size_kb = round(os.path.getsize(backup_path) / 1024, 2)
    caption = (
        f"💾 **LIVE DATABASE BACKUP** 💾\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📅 **Timestamp:** `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`\n"
        f"📊 **File Size:** `{file_size_kb} KB`\n"
        f"🛡️ **Integrity:** 100% Consistent (WAL Mode)\n\n"
        f"💡 Save this file. All your users, referrals, and passwords are encrypted and safely preserved."
    )
    with open(backup_path, "rb") as f:
        await context.bot.send_document(
            chat_id=user.id,
            document=f,
            filename=os.path.basename(backup_path),
            caption=caption,
            parse_mode=ParseMode.MARKDOWN
        )

async def setlogincode_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    if not context.args:
        await update.message.reply_text("Usage: `/setlogincode <new_secret_code>`", parse_mode=ParseMode.MARKDOWN)
        return

    new_code = context.args[0].strip()
    database.set_admin_secret_code(new_code)
    await update.message.reply_text(f"✅ Secret admin login code updated to:\n`{new_code}`", parse_mode=ParseMode.MARKDOWN)

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    stats = database.get_total_stats()
    stock_stats = database.get_stock_stats()
    required = database.get_required_referrals()
    groups = database.get_groups()

    admin_msg = (
        f"⚙️ **ADMIN CONTROL CENTER**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👥 **Total Registered Users:** `{stats['total_users']}`\n"
        f"✅ **Verified Users (Joined Groups):** `{stats['joined_users']}`\n"
        f"🎉 **Total Referrals Completed:** `{stats['completed_referrals']}`\n"
        f"📦 **Key Stock Available:** `{stock_stats['available']}` (Used: `{stock_stats['used']}`)\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🔗 **Group 1:** [{groups['g1_name']}]({groups['g1_url']})\n"
        f"🔗 **Group 2:** [{groups['g2_name']}]({groups['g2_url']})\n"
        f"🎯 **Default Referral Target:** `{required}` Refs\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👇 Select an action from the options below:"
    )
    await update.message.reply_text(
        admin_msg,
        reply_markup=get_admin_inline_keyboard(),
        parse_mode=ParseMode.MARKDOWN
    )

# Group Links Management Commands
async def setgroup1_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    raw = " ".join(context.args).strip()
    if "|" not in raw:
        await update.message.reply_text(
            "Usage:\n`/setgroup1 Channel Name | https://t.me/your_channel`\n\n*(Bot will auto-detect username for verification)*",
            parse_mode=ParseMode.MARKDOWN
        )
        return

    parts = [p.strip() for p in raw.split("|")]
    name, url = parts[0], parts[1]
    chat_id = parts[2] if len(parts) >= 3 else ""
    database.set_group1(name, url, chat_id)
    groups = database.get_groups()
    await update.message.reply_text(
        f"✅ **Group 1 Updated Successfully!**\n"
        f"• Name: `{groups['g1_name']}`\n"
        f"• URL: {groups['g1_url']}\n"
        f"• Verification ID: `{groups['g1_id'] or 'None'}`\n\n"
        f"💡 Run `/testgroups` to confirm bot admin permissions!",
        parse_mode=ParseMode.MARKDOWN
    )

async def setgroup2_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    raw = " ".join(context.args).strip()
    if "|" not in raw:
        await update.message.reply_text(
            "Usage:\n`/setgroup2 Group Name | https://t.me/your_group`\n\n*(Bot will auto-detect username for verification)*",
            parse_mode=ParseMode.MARKDOWN
        )
        return

    parts = [p.strip() for p in raw.split("|")]
    name, url = parts[0], parts[1]
    chat_id = parts[2] if len(parts) >= 3 else ""
    database.set_group2(name, url, chat_id)
    groups = database.get_groups()
    await update.message.reply_text(
        f"✅ **Group 2 Updated Successfully!**\n"
        f"• Name: `{groups['g2_name']}`\n"
        f"• URL: {groups['g2_url']}\n"
        f"• Verification ID: `{groups['g2_id'] or 'None'}`\n\n"
        f"💡 Run `/testgroups` to confirm bot admin permissions!",
        parse_mode=ParseMode.MARKDOWN
    )

# /user Command: Inspect User Details
async def user_details_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    if not context.args or not context.args[0].isdigit():
        await update.message.reply_text("Usage: `/user <user_id>` (e.g. `/user 8884471241`)", parse_mode=ParseMode.MARKDOWN)
        return

    target_id = int(context.args[0])
    info = database.get_user_details(target_id)
    if not info:
        await update.message.reply_text(f"❌ User `{target_id}` not found in database.", parse_mode=ParseMode.MARKDOWN)
        return

    u = info["user"]
    claims_str = "None"
    if info["claims"]:
        claims_str = "\n".join([f"• {c['name']} ({c['claimed_at'][:16]})" for c in info["claims"]])

    msg = (
        f"👤 **USER PROFILE & REFERRAL REPORT**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"• **Name:** {u.get('first_name') or 'N/A'}\n"
        f"• **User ID:** `{u['user_id']}`\n"
        f"• **Username:** @{u['username'] if u.get('username') else 'None'}\n"
        f"• **Group Membership:** {'✅ Verified Member' if u['joined_groups'] else '❌ Not Joined'}\n"
        f"• **Invited By:** `{u.get('referred_by') or 'Organic / Direct'}`\n"
        f"• **Joined At:** {str(u.get('created_at', ''))[:19]}\n\n"
        f"📊 **Referral Breakdown:**\n"
        f"• 🟢 **Available (Spendable):** `{info['available_refs']}` Refs\n"
        f"• 🏆 **Total Lifetime Referrals:** `{info['total_verified_refs']}` Refs\n"
        f"• 🔑 **Spent on VIP Keys:** `{info['spent_refs']}` Refs\n"
        f"• ⏳ **Pending (Unverified):** `{info['pending_refs']}` Refs\n\n"
        f"🎁 **Claimed Products / Keys:**\n{claims_str}"
    )
    await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN)

# /addproduct Command
async def addproduct_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    raw = " ".join(context.args).strip()
    if not raw or "|" not in raw:
        await update.message.reply_text(
            "⚠️ **Format:**\n`/addproduct Name | Password | Required_Refs | Description`\n\n"
            "**Example:**\n`/addproduct Netflix 4K | PASS123 | 3 | Ultra HD Monthly Access`",
            parse_mode=ParseMode.MARKDOWN
        )
        return

    parts = [p.strip() for p in raw.split("|")]
    if len(parts) < 2:
        await update.message.reply_text("⚠️ Please provide at least: `Name | Password`")
        return

    name = parts[0]
    password = parts[1]
    refs = 2
    desc = ""

    if len(parts) >= 3 and parts[2].isdigit():
        refs = int(parts[2])
    if len(parts) >= 4:
        desc = parts[3]

    prod_id = database.add_product(name=name, secret_password=password, required_referrals=refs, description=desc)
    await update.message.reply_text(
        f"✅ **Product Added Successfully! (ID: #{prod_id})**\n\n"
        f"📦 **Name:** {name}\n"
        f"🔑 **Password:** `{password}`\n"
        f"🎯 **Required Referrals:** {refs}\n"
        f"📝 **Description:** {desc or 'N/A'}",
        parse_mode=ParseMode.MARKDOWN
    )

# /setprodpass Command
async def setprodpass_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    if len(context.args) < 2 or not context.args[0].isdigit():
        await update.message.reply_text("Usage: `/setprodpass <product_id> <new_password>`", parse_mode=ParseMode.MARKDOWN)
        return

    prod_id = int(context.args[0])
    new_pass = " ".join(context.args[1:]).strip()

    if database.update_product_password(prod_id, new_pass):
        await update.message.reply_text(f"✅ Password for Product **#{prod_id}** updated to:\n`{new_pass}`", parse_mode=ParseMode.MARKDOWN)
    else:
        await update.message.reply_text(f"❌ Product #{prod_id} not found.")

# /setprodref Command
async def setprodref_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    if len(context.args) < 2 or not context.args[0].isdigit() or not context.args[1].isdigit():
        await update.message.reply_text("Usage: `/setprodref <product_id> <new_referral_target>`", parse_mode=ParseMode.MARKDOWN)
        return

    prod_id = int(context.args[0])
    new_ref = int(context.args[1])

    if database.update_product_referrals(prod_id, new_ref):
        await update.message.reply_text(f"✅ Referral requirement for Product **#{prod_id}** set to: **{new_ref}**", parse_mode=ParseMode.MARKDOWN)
    else:
        await update.message.reply_text(f"❌ Product #{prod_id} not found.")

# /delproduct Command
async def delproduct_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    if not context.args or not context.args[0].isdigit():
        await update.message.reply_text("Usage: `/delproduct <product_id>`", parse_mode=ParseMode.MARKDOWN)
        return

    prod_id = int(context.args[0])
    if database.delete_product(prod_id):
        await update.message.reply_text(f"✅ Product **#{prod_id}** has been removed.", parse_mode=ParseMode.MARKDOWN)
    else:
        await update.message.reply_text(f"❌ Product #{prod_id} not found.")

# /setpic Command
async def setpic_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    if context.args:
        new_url = context.args[0].strip()
        database.set_banner_url(new_url)
        try:
            await update.message.reply_photo(
                photo=new_url,
                caption=f"✅ **Banner Image Updated Successfully!**\n\nNew URL:\n`{new_url}`",
                parse_mode=ParseMode.MARKDOWN
            )
        except Exception as e:
            await update.message.reply_text(
                f"✅ Banner URL saved to database:\n`{new_url}`\n\n*(Note: {e})*",
                parse_mode=ParseMode.MARKDOWN
            )
        return

    photo = None
    if update.message.photo:
        photo = update.message.photo[-1].file_id
    elif update.message.reply_to_message and update.message.reply_to_message.photo:
        photo = update.message.reply_to_message.photo[-1].file_id

    if photo:
        database.set_banner_url(photo)
        await update.message.reply_photo(
            photo=photo,
            caption="✅ **Banner Photo Uploaded and Set Successfully!**\nAll users will now see this picture on their dashboard.",
            parse_mode=ParseMode.MARKDOWN
        )
        return

    await update.message.reply_text(
        "📸 **How to set a Banner Picture:**\n\n"
        "1️⃣ **Via Image URL:**\n`/setpic https://example.com/image.jpg`\n\n"
        "2️⃣ **Via Photo Upload:**\nSend any photo directly with caption `/setpic` or reply to a photo with `/setpic`!",
        parse_mode=ParseMode.MARKDOWN
    )

# /setref Command
async def setref_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    if not context.args or not context.args[0].isdigit():
        await update.message.reply_text("Usage: `/setref <number>` (e.g. `/setref 2`)", parse_mode=ParseMode.MARKDOWN)
        return

    num = int(context.args[0])
    database.set_required_referrals(num)
    await update.message.reply_text(f"✅ Default referral target successfully set to: **{num}**", parse_mode=ParseMode.MARKDOWN)

# /broadcast Command (Supports both text and photo broadcast!)
async def broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        await update.message.reply_text("⛔ Access Denied! Admins only.")
        return

    broadcast_text = " ".join(context.args).strip() if context.args else ""
    photo = None
    if update.message.photo:
        photo = update.message.photo[-1].file_id
        caption_text = (update.message.caption or "").strip()
        if caption_text.lower().startswith("/broadcast"):
            broadcast_text = caption_text[10:].strip()

    if not broadcast_text and not photo:
        await update.message.reply_text("Usage: `/broadcast <your news / announcement message>`\nOr send a photo with caption `/broadcast <message>`", parse_mode=ParseMode.MARKDOWN)
        return

    user_ids = database.get_all_user_ids()
    sent = 0
    failed = 0
    status_msg = await update.message.reply_text(f"📤 Broadcasting news to {len(user_ids)} users...")

    for uid in user_ids:
        try:
            if photo:
                await context.bot.send_photo(chat_id=uid, photo=photo, caption=broadcast_text, parse_mode=ParseMode.MARKDOWN)
            else:
                await context.bot.send_message(chat_id=uid, text=broadcast_text, parse_mode=ParseMode.MARKDOWN)
            sent += 1
        except Exception:
            failed += 1

    await status_msg.edit_text(f"✅ Broadcast Completed!\nDelivered: {sent} | Failed/Blocked: {failed}")

# Handle photos with caption /setpic or /broadcast or /setpass
async def handle_photo_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not database.is_admin(user.id):
        return

    caption = (update.message.caption or "").strip()
    if caption.lower().startswith("/setpic"):
        photo = update.message.photo[-1].file_id
        database.set_banner_url(photo)
        await update.message.reply_photo(
            photo=photo,
            caption="✅ **Banner Photo Uploaded and Set Successfully!**\nAll users will now see this picture on their dashboard.",
            parse_mode=ParseMode.MARKDOWN
        )
    elif caption.lower().startswith("/broadcast"):
        await broadcast_command(update, context)
    elif caption.lower().startswith("/setpassword") or caption.lower().startswith("/setpass"):
        parts = caption.split(maxsplit=1)
        if len(parts) > 1:
            new_pass = parts[1].strip()
            database.set_secret_password(new_pass)
            await update.message.reply_text(f"✅ VIP Password updated to:\n`{new_pass}`", parse_mode=ParseMode.MARKDOWN)

# Handle Admin text messages (e.g. typing new password or stock keys)
async def handle_admin_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not user or not database.is_admin(user.id):
        return

    # Handle Stock Keys Input
    if context.user_data.get("awaiting_stock_keys"):
        context.user_data["awaiting_stock_keys"] = False
        raw_text = update.message.text.strip()
        keys = [k.strip() for k in raw_text.split() if k.strip()]
        added = database.add_stock_keys(keys)
        stats = database.get_stock_stats()

        confirm_msg = (
            f"┏━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
            f"   ✅ **KEYS ADDED TO STOCK!** ✅\n"
            f"┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            f"📥 **Added Keys:** `{added}`\n"
            f"📦 **Available Stock Now:** `{stats['available']}`\n"
            f"📊 **Total Stock:** `{stats['total']}`\n\n"
            f"🎉 Keys are now ready in stock for verified users!"
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("📦 View Key Stock", callback_data="admin_stock_view")],
            [InlineKeyboardButton("🔙 Main Panel", callback_data="admin_center")]
        ])
        await update.message.reply_text(confirm_msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)
        return

    if context.user_data.get("awaiting_password"):
        raw_text = update.message.text.strip()
        context.user_data["awaiting_password"] = False

        if "|" in raw_text:
            parts = [p.strip() for p in raw_text.split("|")]
            name = parts[0]
            pwd = parts[1]
            refs = int(parts[2]) if len(parts) >= 3 and parts[2].isdigit() else database.get_required_referrals()
            desc = parts[3] if len(parts) >= 4 else "VIP Access"
            prod_id = database.add_product(name, pwd, refs, desc)
            database.set_setting("secret_password", pwd)
            database.add_stock_keys([pwd])
            stats = database.get_stock_stats()
            confirm_msg = (
                f"┏━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
                f"   ✅ **KEY ADDED TO STOCK!** ✅\n"
                f"┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
                f"📦 **Name:** {name} (ID: #{prod_id})\n"
                f"🔐 **Key / Password:** `{pwd}`\n"
                f"🎯 **Required Referrals:** `{refs}`\n"
                f"📊 **Total Available Stock:** `{stats['available']}`\n\n"
                f"🎉 Key saved successfully into stock!"
            )
        else:
            required = database.get_required_referrals()
            existing_count = len(database.get_all_products(only_active=True))
            prod_id = database.add_product(f"VIP Key #{existing_count + 1}", raw_text, required, "VIP Access Key")
            database.set_setting("secret_password", raw_text)
            database.add_stock_keys([raw_text])
            stats = database.get_stock_stats()
            confirm_msg = (
                f"┏━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
                f"   ✅ **KEY ADDED TO STOCK!** ✅\n"
                f"┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
                f"📦 **Key ID:** `#{prod_id}`\n"
                f"🔐 **Key / Password:** `{raw_text}`\n"
                f"🎯 **Required Referrals:** `{required}`\n"
                f"📊 **Total Available Stock:** `{stats['available']}`\n\n"
                f"🎉 Key saved successfully into stock!"
            )

        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("📦 View Key Stock", callback_data="admin_stock_view")],
            [InlineKeyboardButton("🔙 Main Panel", callback_data="admin_center")]
        ])
        await update.message.reply_text(confirm_msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)
        return

# Handle Admin document uploads (e.g. uploading .txt password/keys file)
async def handle_admin_document_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not user or not database.is_admin(user.id):
        return

    doc = update.message.document
    if not doc:
        return

    try:
        status_msg = await update.message.reply_text("⏳ Processing keys file...")
        tg_file = await doc.get_file()
        byte_data = await tg_file.download_as_bytearray()
        content = byte_data.decode("utf-8", errors="ignore").strip()

        if not content:
            await status_msg.edit_text("❌ File is empty! No keys found.")
            return

        lines = [line.strip() for line in content.splitlines() if line.strip()]
        added = database.add_stock_keys(lines)
        stats = database.get_stock_stats()

        context.user_data["awaiting_password"] = False
        context.user_data["awaiting_stock_keys"] = False

        confirm_msg = (
            f"┏━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
            f"   ✅ **KEY FILE IMPORTED!** ✅\n"
            f"┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            f"📄 **File Name:** `{doc.file_name}`\n"
            f"📥 **Imported Keys:** `{added}`\n"
            f"📦 **Available Stock Now:** `{stats['available']}`\n"
            f"📊 **Total Stock:** `{stats['total']}`\n\n"
            f"🎉 All keys loaded successfully and ready for users!"
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("📦 View Key Stock", callback_data="admin_stock_view")],
            [InlineKeyboardButton("🔙 Main Panel", callback_data="admin_center")]
        ])
        await status_msg.edit_text(confirm_msg, reply_markup=kb, parse_mode=ParseMode.MARKDOWN)
    except Exception as e:
        logger.error(f"Error handling document: {e}")
        await update.message.reply_text(f"❌ Error processing file: {e}")

# Background Worker: Periodic Automated Live Database Backup (Every 1 Hour)
async def periodic_backup_worker():
    while True:
        try:
            await asyncio.sleep(3600)
            backup_path = database.create_backup()
            logger.info(f"Automated hourly database backup created: {backup_path}")
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.error(f"Error in periodic backup worker: {e}")

# Optional Lightweight Health-check HTTP Server for Cloud Hosting (Render / Koyeb / Railway)
async def start_health_server():
    port_str = os.environ.get("PORT")
    if not port_str:
        return
    try:
        port = int(port_str)
        async def handle_ping(reader, writer):
            try:
                await reader.read(1024)
                response = b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 2\r\nConnection: close\r\n\r\nOK"
                writer.write(response)
                await writer.drain()
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

        server = await asyncio.start_server(handle_ping, "0.0.0.0", port)
        logger.info(f"Free Cloud Hosting Port Binder active on port {port} (Render / Koyeb ready)")
    except Exception as e:
        logger.warning(f"Could not bind cloud PORT: {e}")

# Global Error Handler: Prevents crashes on network timeouts or unexpected errors
async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.error("Exception while handling an update:", exc_info=context.error)
    err_str = str(context.error).lower()
    if "conflict" in err_str:
        logger.warning("Telegram conflict warning: multiple polling instances detected.")
    elif "timed out" in err_str or "network" in err_str:
        logger.warning("Telegram network timeout: polling will automatically recover.")

# Initialize standard 3-Dot Bot Commands
async def post_init(application):
    commands = [
        BotCommand("start", "🚀 Open VIP Dashboard"),
        BotCommand("getkey", "🔑 Get VIP Password"),
        BotCommand("refer", "🔗 My Referral Link & Share"),
    ]
    try:
        await application.bot.set_my_commands(commands)
        logger.info("Bot commands set successfully in 3-dot Menu.")
    except Exception as e:
        logger.warning(f"Could not set bot commands: {e}")

    # Launch background hourly database backup worker
    asyncio.create_task(periodic_backup_worker())
    logger.info("Hourly automated database backup worker active.")

    # Launch cloud health-check server (if running on Render / Koyeb)
    asyncio.create_task(start_health_server())

def main():
    database.init_db()
    print("Database initialized.")

    app = ApplicationBuilder().token(config.BOT_TOKEN).post_init(post_init).build()

    # Register Global Exception Safety
    app.add_error_handler(error_handler)

    # User Commands (Present in 3-dot Menu)
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("getkey", getkey_command))
    app.add_handler(CommandHandler("refer", refer_command))
    app.add_handler(CommandHandler("status", status_command))
    app.add_handler(CommandHandler("claim", getkey_command))
    app.add_handler(CommandHandler("help", help_command))

    # Secret Admin Authentication
    app.add_handler(CommandHandler("login", login_command))
    app.add_handler(CommandHandler("setlogincode", setlogincode_command))

    # Admin Exclusive Commands
    app.add_handler(CommandHandler("admin", admin_command))
    app.add_handler(CommandHandler("stock", stock_command))
    app.add_handler(CommandHandler("keys", stock_command))
    app.add_handler(CommandHandler("addkeys", addkeys_command))
    app.add_handler(CommandHandler("delstock", delstock_command))
    app.add_handler(CommandHandler("setpassword", setpassword_command))
    app.add_handler(CommandHandler("setpass", setpassword_command))
    app.add_handler(CommandHandler("setref", setref_command))
    app.add_handler(CommandHandler("setgroup1", setgroup1_command))
    app.add_handler(CommandHandler("setgroup2", setgroup2_command))
    app.add_handler(CommandHandler("testgroups", testgroups_command))
    app.add_handler(CommandHandler("user", user_details_command))
    app.add_handler(CommandHandler("users", users_command))
    app.add_handler(CommandHandler("addproduct", addproduct_command))
    app.add_handler(CommandHandler("setprodpass", setprodpass_command))
    app.add_handler(CommandHandler("setprodref", setprodref_command))
    app.add_handler(CommandHandler("delproduct", delproduct_command))
    app.add_handler(CommandHandler("setpic", setpic_command))
    app.add_handler(CommandHandler("broadcast", broadcast_command))
    app.add_handler(CommandHandler("backup", backup_command))

    # User Inline Callbacks
    app.add_handler(CallbackQueryHandler(check_joined_callback, pattern="^check_joined$"))
    app.add_handler(CallbackQueryHandler(get_key_callback, pattern="^get_key$"))
    app.add_handler(CallbackQueryHandler(refresh_dashboard_callback, pattern="^refresh_dashboard$"))
    app.add_handler(CallbackQueryHandler(claim_password_callback, pattern="^claim_password$"))
    app.add_handler(CallbackQueryHandler(view_product_callback, pattern="^view_product:"))
    app.add_handler(CallbackQueryHandler(ref_history_callback, pattern="^ref_history$"))
    app.add_handler(CallbackQueryHandler(leaderboard_callback, pattern="^leaderboard$"))

    # Admin Inline Callbacks
    app.add_handler(CallbackQueryHandler(admin_center_callback, pattern="^admin_center$"))
    app.add_handler(CallbackQueryHandler(admin_refresh_callback, pattern="^admin_refresh$"))
    app.add_handler(CallbackQueryHandler(admin_stock_view_callback, pattern="^admin_stock_view$"))
    app.add_handler(CallbackQueryHandler(admin_add_keys_prompt_callback, pattern="^admin_add_keys_prompt$"))
    app.add_handler(CallbackQueryHandler(admin_del_stock_menu_callback, pattern="^admin_del_stock_menu$"))
    app.add_handler(CallbackQueryHandler(del_stock_qty_callback, pattern="^del_stock_qty:"))
    app.add_handler(CallbackQueryHandler(del_stock_all_callback, pattern="^del_stock_all$"))
    app.add_handler(CallbackQueryHandler(admin_manage_pass_callback, pattern="^admin_manage_pass$"))
    app.add_handler(CallbackQueryHandler(admin_prompt_password_callback, pattern="^admin_prompt_password$"))
    app.add_handler(CallbackQueryHandler(admin_cancel_password_callback, pattern="^admin_cancel_password$"))
    app.add_handler(CallbackQueryHandler(admin_txt_guide_callback, pattern="^admin_txt_guide$"))
    app.add_handler(CallbackQueryHandler(admin_manage_prods_callback, pattern="^admin_manage_prods$"))
    app.add_handler(CallbackQueryHandler(admin_manage_groups_callback, pattern="^admin_manage_groups$"))
    app.add_handler(CallbackQueryHandler(admin_test_groups_callback, pattern="^admin_test_groups$"))
    app.add_handler(CallbackQueryHandler(admin_del_prod_callback, pattern="^adm_del_prod:"))
    app.add_handler(CallbackQueryHandler(admin_edit_pass_prompt, pattern="^adm_edit_pass:"))
    app.add_handler(CallbackQueryHandler(admin_edit_ref_prompt, pattern="^adm_edit_ref:"))
    app.add_handler(CallbackQueryHandler(admin_add_guide_callback, pattern="^adm_add_guide$"))
    app.add_handler(CallbackQueryHandler(admin_setref_menu_callback, pattern="^admin_setref_menu$"))
    app.add_handler(CallbackQueryHandler(quick_set_ref_callback, pattern="^quick_ref:"))
    app.add_handler(CallbackQueryHandler(admin_setpic_info, pattern="^admin_setpic_info$"))
    app.add_handler(CallbackQueryHandler(admin_broadcast_info, pattern="^admin_broadcast_info$"))
    app.add_handler(CallbackQueryHandler(admin_code_info, pattern="^admin_code_info$"))
    app.add_handler(CallbackQueryHandler(admin_recent_users_callback, pattern="^admin_recent_users$"))
    app.add_handler(CallbackQueryHandler(admin_download_backup_callback, pattern="^admin_download_backup$"))

    # Real-time Chat Member Updates (detect member leaving groups -> revoke referral -1)
    app.add_handler(ChatMemberHandler(chat_member_update_handler, ChatMemberHandler.CHAT_MEMBER))

    # Photo, Document, and Text uploads
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo_upload))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_admin_document_upload))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_admin_text_message))

    print(f"🤖 Ultra Clean VIP Referral Bot started! Token: {config.BOT_TOKEN[:10]}...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
