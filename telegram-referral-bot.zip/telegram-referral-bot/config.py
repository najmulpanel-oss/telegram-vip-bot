import os
from dotenv import load_dotenv

load_dotenv()

# Telegram Bot Token (Original Main Bot)
BOT_TOKEN = os.getenv("BOT_TOKEN", "9141729003:AAFU48CwOo6awXElUHnts664fRSFqpep59Q")
LOG_BOT_TOKEN = os.getenv("LOG_BOT_TOKEN", "9057778207:AAF4Ae8BfC_xSWyy5JBa2bChFL-PRK4xT2c")

# Channels / Groups to join
GROUP_1_NAME = os.getenv("GROUP_1_NAME", "👥 Join Group 1")
GROUP_1_URL = os.getenv("GROUP_1_URL", "https://t.me/telegram")
GROUP_1_ID = os.getenv("GROUP_1_ID", "").strip()

GROUP_2_NAME = os.getenv("GROUP_2_NAME", "👥 Join Group 2")
GROUP_2_URL = os.getenv("GROUP_2_URL", "https://t.me/durov")
GROUP_2_ID = os.getenv("GROUP_2_ID", "").strip()

# Referral requirement to unlock password (default: 2)
REQUIRED_REFERRALS = int(os.getenv("REQUIRED_REFERRALS", "2"))

# Default secret password
DEFAULT_SECRET_PASSWORD = os.getenv("SECRET_PASSWORD", "FREEPANEL_VIP_2026")

# Default Banner Image URL (can be customized via /setpic or in .env)
DEFAULT_BANNER_URL = os.getenv(
    "BANNER_URL", 
    "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80"
)

# Panel / Website link
PANEL_URL = os.getenv("PANEL_URL", "https://t.me/freepanelworld_bot")

# Support link or admin contact
SUPPORT_URL = os.getenv("SUPPORT_URL", "https://t.me/telegram")

# Admin Telegram User IDs (User ID 8884471241 is pre-configured as the owner)
ADMIN_IDS = [x.strip() for x in os.getenv("ADMIN_ID", "8884471241").split(",") if x.strip()]
